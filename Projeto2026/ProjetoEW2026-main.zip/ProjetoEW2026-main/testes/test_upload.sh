#!/bin/bash
# ============================================================
#  Testes de Upload e Ingestao - Data API
#  Plataforma de Gestao e Disponibilizacao de Recursos Educativos
# ============================================================
#  Uso: ./test_upload.sh [BASE_URL]
#  Exemplo: ./test_upload.sh http://localhost:3000
# ============================================================

BASE_URL="${1:-http://localhost:3000}"
FIXTURES_DIR="$(cd "$(dirname "$0")/fixtures" && pwd)"

PASS=0
FAIL=0
TOTAL=0

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# ---- Funcoes auxiliares ----

run_test() {
    local name="$1"
    local expected_status="$2"
    local actual_status="$3"
    local body="$4"
    local check_field="$5"

    TOTAL=$((TOTAL + 1))

    if [ "$actual_status" = "$expected_status" ]; then
        # Se houver campo extra para verificar
        if [ -n "$check_field" ]; then
            if echo "$body" | python3 -c "import sys,json; d=json.load(sys.stdin); assert $check_field" 2>/dev/null; then
                PASS=$((PASS + 1))
                echo -e "  ${GREEN}PASS${NC} [$actual_status] $name"
            else
                FAIL=$((FAIL + 1))
                echo -e "  ${RED}FAIL${NC} [$actual_status] $name — campo em falta na resposta"
                echo "       Resposta: $(echo "$body" | head -c 200)"
            fi
        else
            PASS=$((PASS + 1))
            echo -e "  ${GREEN}PASS${NC} [$actual_status] $name"
        fi
    else
        FAIL=$((FAIL + 1))
        echo -e "  ${RED}FAIL${NC} [$actual_status] $name — esperado $expected_status"
        echo "       Resposta: $(echo "$body" | head -c 200)"
    fi
}

# ---- Verificar se a API esta disponivel ----

echo ""
echo -e "${YELLOW}Verificar conexao com a API ($BASE_URL)...${NC}"
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/api/resources" 2>/dev/null)
if [ "$HTTP_CODE" != "200" ]; then
    echo -e "${RED}ERRO: API nao responde em $BASE_URL (HTTP $HTTP_CODE)${NC}"
    echo "Certifica-te que os containers Docker estao a correr: docker compose up -d"
    exit 1
fi
echo -e "${GREEN}API disponivel!${NC}"
echo ""

# ============================================================
#  1. UPLOAD DE FICHEIRO SIMPLES (POST /api/resources/register)
# ============================================================
echo -e "${YELLOW}=== 1. Upload de Ficheiro Simples ===${NC}"

# 1.1 Upload valido com ficheiro JSON
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/resources/register" \
    -F "produtor=u1" \
    -F "tipo=datasets/json" \
    -F "titulo=Teste Upload Simples" \
    -F "subtitulo=Ficheiro de teste automatizado" \
    -F "visibilidade=PUBLIC" \
    -F "hashtags=teste,automatizado" \
    -F "file=@$FIXTURES_DIR/recurso_teste.json")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Upload ficheiro JSON valido" "201" "$STATUS" "$BODY" "'mensagem' in d"

# Guardar ID para testes posteriores
RESOURCE_ID=$(echo "$BODY" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)

# 1.2 Upload sem ficheiro (apenas metadados)
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/resources/register" \
    -H "Content-Type: application/json" \
    -d '{"produtor":"u1","tipo":"texto/fichas","titulo":"Recurso sem ficheiro","visibilidade":{"status":"PUBLIC"}}')
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Criar recurso sem ficheiro (JSON body)" "201" "$STATUS" "$BODY" "'mensagem' in d"

echo ""

# ============================================================
#  2. INGESTAO SIP BAGIT (POST /api/ingest)
# ============================================================
echo -e "${YELLOW}=== 2. Ingestao SIP (ZIP BagIt) ===${NC}"

# 2.1 SIP valido com 2 ficheiros
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/ingest" \
    -F "titulo=Dataset Meteorologia e Alunos" \
    -F "tipo=datasets/json" \
    -F "produtor=u1" \
    -F "visibilidade=PUBLIC" \
    -F "subtitulo=SIP BagIt com 2 ficheiros" \
    -F "hashtags=meteorologia,alunos,teste" \
    -F "file=@$FIXTURES_DIR/sip_valido.zip")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "SIP valido (ZIP BagIt com 2 ficheiros)" "201" "$STATUS" "$BODY" "'recurso' in d"

# Guardar ID do recurso SIP para exportacao
SIP_RESOURCE_ID=$(echo "$BODY" | python3 -c "import sys,json; print(json.load(sys.stdin).get('recurso',{}).get('_id',''))" 2>/dev/null)

# 2.2 SIP com checksum invalido
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/ingest" \
    -F "titulo=SIP Invalido" \
    -F "tipo=outros" \
    -F "produtor=u1" \
    -F "file=@$FIXTURES_DIR/sip_checksum_invalido.zip")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "SIP com checksum invalido (deve falhar)" "400" "$STATUS" "$BODY" "'relatorio' in d and d['relatorio']['valido']==False"

# 2.3 SIP sem manifest BagIt
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/ingest" \
    -F "titulo=Sem Manifest" \
    -F "tipo=outros" \
    -F "produtor=u1" \
    -F "file=@$FIXTURES_DIR/sip_sem_manifest.zip")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "SIP sem manifest BagIt (deve falhar)" "400" "$STATUS" "$BODY" "'relatorio' in d and 'manifest' in d['relatorio'].get('motivo','')"

# 2.4 Ficheiro nao-ZIP
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/ingest" \
    -F "titulo=Nao ZIP" \
    -F "tipo=outros" \
    -F "produtor=u1" \
    -F "file=@$FIXTURES_DIR/recurso_teste.json")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Ficheiro nao-ZIP (deve falhar)" "400" "$STATUS" "$BODY" "'relatorio' in d and 'ZIP' in d['relatorio'].get('motivo','')"

# 2.5 SIP sem ficheiro enviado
RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/ingest" \
    -F "titulo=Sem ficheiro" \
    -F "tipo=outros" \
    -F "produtor=u1")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "SIP sem ficheiro enviado (deve falhar)" "400" "$STATUS" "$BODY"

echo ""

# ============================================================
#  3. GESTAO DE ESTADO (aprovar/rejeitar)
# ============================================================
echo -e "${YELLOW}=== 3. Gestao de Estado (Aprovar/Rejeitar) ===${NC}"

# 3.1 Aprovar recurso
if [ -n "$RESOURCE_ID" ]; then
    RESP=$(curl -s -w "\n%{http_code}" -X PATCH "$BASE_URL/api/resources/$RESOURCE_ID/aprovar")
    BODY=$(echo "$RESP" | sed '$d')
    STATUS=$(echo "$RESP" | tail -1)
    run_test "Aprovar recurso ($RESOURCE_ID)" "200" "$STATUS" "$BODY" "'aprovado' in d.get('recurso',{}).get('estado','')"
else
    echo -e "  ${RED}SKIP${NC} Aprovar recurso — sem ID disponivel"
fi

# 3.2 Rejeitar recurso SIP
if [ -n "$SIP_RESOURCE_ID" ]; then
    RESP=$(curl -s -w "\n%{http_code}" -X PATCH "$BASE_URL/api/resources/$SIP_RESOURCE_ID/rejeitar")
    BODY=$(echo "$RESP" | sed '$d')
    STATUS=$(echo "$RESP" | tail -1)
    run_test "Rejeitar recurso SIP ($SIP_RESOURCE_ID)" "200" "$STATUS" "$BODY" "'rejeitado' in d.get('recurso',{}).get('estado','')"
else
    echo -e "  ${RED}SKIP${NC} Rejeitar recurso — sem ID disponivel"
fi

# 3.3 Filtrar por estado
RESP=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/resources?estado=aprovado")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Filtrar recursos por estado=aprovado" "200" "$STATUS" "$BODY"

# 3.4 Aprovar/rejeitar recurso inexistente
RESP=$(curl -s -w "\n%{http_code}" -X PATCH "$BASE_URL/api/resources/inexistente999/aprovar")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Aprovar recurso inexistente (deve falhar)" "404" "$STATUS" "$BODY"

echo ""

# ============================================================
#  4. EXPORTACAO DIP (GET /api/resources/:id/export)
# ============================================================
echo -e "${YELLOW}=== 4. Exportacao DIP ===${NC}"

# 4.1 Exportar recurso aprovado (usar um dos recursos seed que sao aprovados)
RESP=$(curl -s -w "\n%{http_code}" -o /tmp/dip_test.zip "$BASE_URL/api/resources/r1/export")
STATUS=$(echo "$RESP" | tail -1)
if [ "$STATUS" = "200" ]; then
    # Verificar se e um ZIP valido
    if unzip -t /tmp/dip_test.zip >/dev/null 2>&1; then
        TOTAL=$((TOTAL + 1))
        PASS=$((PASS + 1))
        echo -e "  ${GREEN}PASS${NC} [200] Exportar DIP de recurso aprovado (r1) — ZIP valido"
        # Mostrar conteudo do DIP
        echo "       Conteudo do DIP:"
        unzip -l /tmp/dip_test.zip 2>/dev/null | grep -E "^\s+[0-9]" | head -5 | sed 's/^/       /'
    else
        TOTAL=$((TOTAL + 1))
        FAIL=$((FAIL + 1))
        echo -e "  ${RED}FAIL${NC} [200] Exportar DIP — resposta nao e um ZIP valido"
    fi
else
    TOTAL=$((TOTAL + 1))
    # Pode ser 403 se o recurso nao esta aprovado, ou 404
    BODY=$(cat /tmp/dip_test.zip 2>/dev/null)
    echo -e "  ${RED}FAIL${NC} [$STATUS] Exportar DIP de recurso aprovado (r1)"
    echo "       Resposta: $(echo "$BODY" | head -c 200)"
    FAIL=$((FAIL + 1))
fi

# 4.2 Exportar recurso nao aprovado (deve falhar)
if [ -n "$SIP_RESOURCE_ID" ]; then
    RESP=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/resources/$SIP_RESOURCE_ID/export")
    BODY=$(echo "$RESP" | sed '$d')
    STATUS=$(echo "$RESP" | tail -1)
    run_test "Exportar DIP de recurso rejeitado (deve falhar)" "403" "$STATUS" "$BODY"
fi

# 4.3 Exportar recurso inexistente
RESP=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/resources/inexistente999/export")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Exportar DIP de recurso inexistente (deve falhar)" "404" "$STATUS" "$BODY"

echo ""

# ============================================================
#  5. EXPORT/IMPORT BULK (GET/POST /api/export)
# ============================================================
echo -e "${YELLOW}=== 5. Export/Import Bulk ===${NC}"

# 5.1 Export all
RESP=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/export")
BODY=$(echo "$RESP" | sed '$d')
STATUS=$(echo "$RESP" | tail -1)
run_test "Export bulk (GET /api/export)" "200" "$STATUS" "$BODY"

echo ""

# ============================================================
#  RESUMO
# ============================================================
echo "============================================================"
echo -e "  RESULTADOS: $TOTAL testes | ${GREEN}$PASS passed${NC} | ${RED}$FAIL failed${NC}"
echo "============================================================"
echo ""

# Limpeza dos recursos criados durante os testes
if [ -n "$RESOURCE_ID" ]; then
    curl -s -X DELETE "$BASE_URL/api/resources/$RESOURCE_ID" > /dev/null 2>&1
fi
if [ -n "$SIP_RESOURCE_ID" ]; then
    curl -s -X DELETE "$BASE_URL/api/resources/$SIP_RESOURCE_ID" > /dev/null 2>&1
fi

# Exit code baseado nos resultados
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
