const jwt = require('jsonwebtoken')

const COOKIE_NAME = process.env.AUTH_COOKIE || 'auth_token'
const JWT_SECRET = process.env.JWT_SECRET
const AUTH_PUBLIC_URL = process.env.AUTH_PUBLIC_URL || 'http://localhost:3002'

// Middleware que tenta decifrar o cookie e popular req.user e res.locals.user.
// Não bloqueia o pedido — só define o utilizador se o token for válido.
function attachUser(req, res, next) {
    // URL pública do servidor de autenticação (acessível pelo browser),
    // disponível em todas as views para construir links de login/registo/logout
    res.locals.authUrl = AUTH_PUBLIC_URL

    const token = req.cookies && req.cookies[COOKIE_NAME]
    if (!token) {
        req.user = null
        req.token = null
        res.locals.user = null
        return next()
    }

    jwt.verify(token, JWT_SECRET, (err, payload) => {
        if (err) {
            req.user = null
            req.token = null
            res.locals.user = null
        } else {
            req.user = payload
            req.token = token
            res.locals.user = payload
        }
        next()
    })
}

// Bloqueia o pedido (redireciona para o login do servidor de auth) se não autenticado.
function requireAuth(req, res, next) {
    if (!req.user) {
        return res.redirect(`${AUTH_PUBLIC_URL}/login`)
    }
    next()
}

// Restringe o acesso a utilizadores com um dos níveis indicados.
function requireLevel(...levels) {
    return (req, res, next) => {
        if (!req.user) return res.redirect(`${AUTH_PUBLIC_URL}/login`)
        if (!levels.includes(req.user.nivel)) {
            return res.status(403).render('error', {
                message: 'Sem permissões para esta operação.',
                error: { status: 403 }
            })
        }
        next()
    }
}

// Helper para construir headers com o token JWT atual (para reencaminhar para a data-api)
function authHeaders(req) {
    return req.token ? { Authorization: `Bearer ${req.token}` } : {}
}

module.exports = { attachUser, requireAuth, requireLevel, authHeaders }
