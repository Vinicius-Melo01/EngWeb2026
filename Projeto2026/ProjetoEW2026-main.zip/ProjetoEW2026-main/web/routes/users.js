var express = require('express');
var router = express.Router();
var axios = require('axios');
const { authHeaders, requireLevel } = require('../middleware/auth')

const API_URL = process.env.DATA_API_URL

// Todas as rotas de utilizadores requerem nível administrador
router.use('/rep/users', requireLevel('administrador'))

function getDate(){
  return new Date().toISOString().substring(0, 10);
}

// Listagem de utilizadores
router.get('/rep/users', async function(req, res, next) {
  try{
    const resposta = await axios.get(`${API_URL}/api/users`, {
      params: req.query,
      headers: authHeaders(req)
    });
    const date = getDate();
    res.render('utilizadores', { users: resposta.data , date: date, query: req.query });
  } catch (erro){
      next(erro);
  }
});

router.get('/rep/users/register', async (req, res, next) => {
  try {
    const filiacoesResp = await axios.get(`${API_URL}/api/filiacoes?ativa=true`, { headers: authHeaders(req) });
    const date = getDate();
    res.render('utilizador_form', { user: {}, mode: 'register', date: date, filiacoes: filiacoesResp.data });
  } catch (erro) {
    next(erro);
  }
});
// Envio dos dados do utilizador para o servidor aplicacional (registo)
router.post('/rep/users/register', async (req, res, next) => {
  try {
    await axios.post(`${API_URL}/api/users/register`, req.body);
    res.redirect('/rep/users');
  } catch (erro) {
    next(erro);
  }
})

// Remover um utilizador
router.get('/rep/users/delete/:id', async function(req, res, next) {
    try {
        const id = req.params.id;

        await axios.delete(`${API_URL}/api/users/${id}`, {
            headers: authHeaders(req)
        });

        res.redirect('/rep/users');
    } catch (erro) {
        console.error("Erro na eliminação:", erro.response?.data || erro.message);
        res.status(500).json({ error: "Erro ao eliminar utilizador" });
    }
});

// Form de edição de um utilizador
router.get('/rep/users/edit/:id', async function(req, res, next) {
  try {
    const id = req.params.id;
    const [userResp, filiacoesResp] = await Promise.all([
      axios.get(`${API_URL}/api/users/${id}`, { headers: authHeaders(req) }),
      axios.get(`${API_URL}/api/filiacoes?ativa=true`, { headers: authHeaders(req) })
    ]);
    const date = getDate();
    res.render('utilizador_form', {
      user: userResp.data,
      mode: 'edit',
      date: date,
      filiacoes: filiacoesResp.data
    });
  } catch (erro) {
    next(erro);
  }
});

// Process de edição dos dados de um utilizador
router.post('/rep/users/edit/:id', async function(req, res, next) {
  try {
    const id = req.params.id;

    // debug
    console.log("A atualizar utilizador com id= ", id);
    console.log("Dados recebidos:", req.body);
    
    const updateData = { ...req.body };

    if (updateData.password === '' || !updateData.password) {
      delete updateData.password;
    }

    if (updateData.ativo !== undefined) {
      updateData.ativo = updateData.ativo === 'true' || updateData.ativo === true;
    }

    delete updateData._id;
    delete updateData.dataRegisto;

    await axios.patch(`${API_URL}/api/users/${id}`, updateData, {
      headers: authHeaders(req)
    });

    console.log("Utilizador atualizado com sucesso!");
    res.redirect('/rep/users');
  } catch (erro) {
    console.error("Erro na atualização:", erro.response?.data || erro.message);
    
    // Se for erro de validação, podemos passar a mensagem para a view
    if (erro.response?.status === 400) {
      req.flash('error', erro.response.data.erro || 'Erro na validação dos dados');
    }
    next(erro);
  }
});


// Ver dados do utilizador
router.get('/rep/users/:id', async function(req, res, next) {
  try{
    const id = req.params.id;
    const resposta = await axios.get(`${API_URL}/api/users/${id}`, {
      headers: authHeaders(req)
    });
    const date = getDate();
    res.render('utilizador', { user: resposta.data , date: date});
  } catch (erro) {
    next(erro);
  }
});

module.exports = router;
