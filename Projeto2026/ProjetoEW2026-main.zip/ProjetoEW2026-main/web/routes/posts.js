var express = require('express');
var router = express.Router();
var axios = require('axios');
const { authHeaders } = require('../middleware/auth')

const API_URL = process.env.DATA_API_URL

function getDate(){
  return new Date().toISOString().substring(0, 10);
}

// Listagem de posts ordenados por data de criação
router.get('/rep/posts', async function(req, res, next) {
  try{
    const params = {
      ...req.query,
      sort: req.query.sort || 'dataCriacao',
      order: req.query.order || 'desc'
    }
    const resposta = await axios.get(`${API_URL}/api/posts`, {
      params,
      headers: authHeaders(req)
    });
    const date = getDate();
    res.render('posts/posts', { posts: resposta.data , date: date, query: req.query });
  } catch (erro){
    next(erro);
  }
});

// Form de criação de novo post
router.get('/rep/posts/register', async (req, res, next) => {
  try {
    const user = req.user;
    if (req.user.nivel === 'consumidor') {
      return res.status(403).render('error', {
        message: 'Sem permissão para criar posts',
        error: { status: 403 }
      });
    }
    // Vai buscar apenas os resources aprovados
    const resposta = await axios.get(`${API_URL}/api/resources`, {
      headers: authHeaders(req)
    });
    const date = getDate();
    res.render('posts/post_form', {post: {}, mode: 'register', date: date, resources: resposta.data});
  } catch (erro) {
    next(erro);
  }
});

// Envio dos dados do post para o servidor aplicacional (criação)
router.post('/rep/posts/register', async (req, res, next) => {
  try {
    const body = {
      ...req.body,
      produtor: req.user.sub
    }
    await axios.post(`${API_URL}/api/posts/register`, body, {
      headers: authHeaders(req)
    });
    res.redirect('/rep/posts');
  } catch (erro) {
    next(erro);
  }
});

// Form de edição de um post
router.get('/rep/posts/edit/:id', async function(req, res, next) {
  try {
    const id = req.params.id;
  
    const respostaPost = await axios.get(`${API_URL}/api/posts/${id}`, {
      headers: authHeaders(req)
    });

    // Verificar se o utilizador em questão pode aceder à página de edição um post
    const post = respostaPost.data;
    const user = req.user;
    if (user.nivel !== 'administrador' && !(user.nivel === 'produtor' && post.produtor === user.sub)) {
      return res.status(403).render('error', {
        message: 'Sem permissão para editar este post',
        error: { status: 403 }
      });
    }

    // Vai buscar apenas os resources aprovados
    const respostaResources = await axios.get(`${API_URL}/api/resources`, {
      headers: authHeaders(req)
    });
    const date = getDate();
    res.render('posts/post_form', {
      post: post, 
      mode: 'edit', 
      date: date,
      resources: respostaResources.data
    });
  } catch (erro) {
    next(erro);
  }
});

// Página de um post específico por id
router.get('/rep/posts/:id', async function(req, res, next) {
  try{
    const id = req.params.id;
    const resposta = await axios.get(`${API_URL}/api/posts/${id}`, { 
      headers: authHeaders(req) 
    });
    const post = resposta.data;
    
    // Buscar comentários do post
    let comentarios = [];
    if(post.comentarios && post.comentarios.length > 0) {
      const respostaComentarios = await axios.get(`${API_URL}/api/comments`, {
        params: { post: id, sort: 'data', order: 'desc' },
        headers: authHeaders(req) 
      });
      comentarios = respostaComentarios.data;
    }
    
    const date = getDate();
    res.render('posts/post', { post: post, comentarios: comentarios, date: date});
  } catch (erro) {
    if (erro.response) {
      const status = erro.response.status;

      if (status === 404) {
        return res.status(404).render('error', { 
          message: 'Post não encontrado' 
        });
      }

      if (status === 403) {
        return res.status(403).render('error', { 
          message: 'Não tem permissão para aceder a este post' 
        });
      }
    }
    next(erro);
  }
});

// Process de edição dos dados de um post
router.post('/rep/posts/edit/:id', async function(req, res, next) {
  try {
    const id = req.params.id;
    
    const updateData = { ...req.body };
    
    delete updateData._id;          
    delete updateData.dataCriacao;  
  
    updateData.dataUltimoAcesso = getDate();
    
    await axios.patch(`${API_URL}/api/posts/${id}`, updateData, {
      headers: authHeaders(req)
    });

    res.redirect('/rep/posts');
  } catch (erro) {
    console.error("Erro na atualização:", erro.response?.data || erro.message);
    
    if (erro.response?.status === 400) {
      req.flash('error', erro.response.data.erro || 'Erro na validação dos dados');
    }
    next(erro);
  }
});

// Form de criação de um novo comentário relativo a um post
router.get('/rep/posts/:id/comments/create', async function(req, res, next) {
  try {
    const id = req.params.id;
    const resposta = await axios.get(`${API_URL}/api/posts/${id}`, {
      headers: authHeaders(req)
    });
    const date = getDate();
    res.render('posts/comment_form', {
      post: resposta.data,
      comment: {},
      mode: 'create',
      date: date
    });
  } catch (erro) {
    next(erro);
  }
});

// Envio dos dados do comentário para o servidor aplicacional (criação)
router.post('/rep/posts/:id/comments/register', async function(req, res, next) {
  try {
    const postId = req.params.id;

    await axios.post(`${API_URL}/api/posts/${postId}/comments`, req.body, {
      headers: authHeaders(req)
    });
    res.redirect(`/rep/posts/${postId}`);
  } catch (erro) {
    next(erro);
  }
});

// Remover um post 
router.get('/rep/posts/delete/:id', async function(req, res, next) {
    try {
        const id = req.params.id;
        
        await axios.delete(`${API_URL}/api/posts/${id}`, {
          headers: authHeaders(req)
        });
        
        res.redirect('/rep/posts');
    } catch (erro) {
        if (erro.response && erro.response.status === 403) {
            return res.status(403).render('error', {
                message: 'Sem permissão para eliminar este post',
                error: { status: 403 }
            });
        }
        next(erro);
    }
});

// ============================================
// ROTAS DE COMENTÁRIOS (Endpoints Compostos)
// ============================================

// Form de edição de um comentário de um post
router.get('/rep/posts/:postId/comments/:commentId/edit', async function(req, res, next) {
  try {
    const { postId, commentId } = req.params;
    const respostaPost = await axios.get(`${API_URL}/api/posts/${postId}`, {
      headers: authHeaders(req)
    });
    const respostaComment = await axios.get(`${API_URL}/api/comments/${commentId}`, {
      headers: authHeaders(req)
    });
    
    const user = req.user;
    const comment = respostaComment.data

    const isAdmin = user.nivel === 'administrador';
    const isOwner = user.sub === comment.criador;

    if (!isAdmin && !isOwner){
      return res.status(403).render('error', {
        message: 'Sem permissão para editar este comentário',
        error: { status: 403 }
      });
    }

    const date = getDate();
    res.render('posts/comment_form', {
      post: respostaPost.data,
      comment: comment,
      mode: 'edit',
      date: date
    });
  } catch (erro) {
    next(erro);
  }
});

// Processar edição de comentário
router.post('/rep/posts/:postId/comments/:commentId/edit', async function(req, res, next) {
  try {
    const { postId, commentId } = req.params;
    
    await axios.patch(`${API_URL}/api/posts/${postId}/comments/${commentId}`, 
      req.body, {
      headers: authHeaders(req)
      });
    res.redirect(`/rep/posts/${postId}`);
  } catch (erro) {
    next(erro);
  }
});

// Remover um comentário de um post
router.get('/rep/posts/:postId/comments/:commentId/delete', async function(req, res, next) {
  try {
    const { postId, commentId } = req.params;
    
    await axios.delete(`${API_URL}/api/posts/${postId}/comments/${commentId}`, {
      headers: authHeaders(req)
    });
    res.redirect(`/rep/posts/${postId}`);
  } catch (erro) {
    if (erro.response && erro.response.status === 403) {
        return res.status(403).render('error', {
            message: 'Sem permissão para eliminar este comentário',
            error: { status: 403 }
        });
    }
    next(erro);
  }
});

module.exports = router;