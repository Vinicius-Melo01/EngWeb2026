var express = require('express');
var router = express.Router();
var axios = require('axios');

const API_URL = process.env.DATA_API_URL

function getDate(){
  return new Date().toISOString().substring(0, 10);
}

// Listagem de comentários 
router.get('/rep/comments', async function(req, res, next) {
  try {
    const resposta = await axios.get(`${API_URL}/api/comments`, {
      params: { ...req.query, sort: 'data', order: 'desc' }
    });
    const date = getDate();
    res.render('comments/comments', { comments: resposta.data, date: date });
  } catch (erro) {
    next(erro);
  }
});

// Visualização de um comentário específico
router.get('/rep/comments/:id', async function(req, res, next) {
  try {
    const id = req.params.id;
    const resposta = await axios.get(`${API_URL}/api/comments/${id}`);
    const date = getDate();
    res.render('comments/comment', { comment: resposta.data, date: date });
  } catch (erro) {
    next(erro);
  }
});

module.exports = router;
