const express = require('express');
const router = express.Router();
const axios = require('axios');
const { authHeaders, requireLevel } = require('../middleware/auth');

const API_URL = `${process.env.DATA_API_URL}/api`;

// Toda esta área é restrita a administradores
router.use(requireLevel('administrador'));

// GET /rep/filiacoes — listar
router.get('/', async (req, res, next) => {
    try {
        const response = await axios.get(`${API_URL}/filiacoes`, {
            headers: authHeaders(req),
            params: req.query
        });
        res.render('filiacoes/filiacoes_list', {
            title: 'Gestão de Filiações',
            filiacoes: response.data,
            user: req.user,
            query: req.query
        });
    } catch (error) {
        next(error);
    }
});

// GET /rep/filiacoes/new — formulário de criação
router.get('/new', (req, res) => {
    res.render('filiacoes/filiacoes_form', {
        title: 'Nova Filiação',
        user: req.user,
        filiacao: {}
    });
});

// POST /rep/filiacoes/new — processar criação
router.post('/new', async (req, res, next) => {
    try {
        const body = { ...req.body, ativa: req.body.ativa === 'true' };
        await axios.post(`${API_URL}/filiacoes`, body, { headers: authHeaders(req) });
        res.redirect('/rep/filiacoes');
    } catch (error) {
        next(error);
    }
});

// GET /rep/filiacoes/edit/:id — formulário de edição
router.get('/edit/:id', async (req, res, next) => {
    try {
        const response = await axios.get(`${API_URL}/filiacoes/${req.params.id}`, { headers: authHeaders(req) });
        res.render('filiacoes/filiacoes_form', {
            title: 'Editar Filiação',
            user: req.user,
            filiacao: response.data
        });
    } catch (error) {
        next(error);
    }
});

// POST /rep/filiacoes/edit/:id — processar edição
router.post('/edit/:id', async (req, res, next) => {
    try {
        const body = { ...req.body, ativa: req.body.ativa === 'true' };
        await axios.put(`${API_URL}/filiacoes/${req.params.id}`, body, { headers: authHeaders(req) });
        res.redirect('/rep/filiacoes');
    } catch (error) {
        next(error);
    }
});

// POST /rep/filiacoes/delete/:id — soft-delete (desativar)
router.post('/delete/:id', async (req, res, next) => {
    try {
        await axios.delete(`${API_URL}/filiacoes/${req.params.id}`, { headers: authHeaders(req) });
        res.redirect('/rep/filiacoes');
    } catch (error) {
        next(error);
    }
});

module.exports = router;
