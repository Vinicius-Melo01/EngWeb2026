var express = require('express');
var axios = require('axios');
var router = express.Router();
const multer = require('multer')
const { authHeaders, requireLevel } = require('../middleware/auth')

const API_URL = process.env.DATA_API_URL
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024 } })

function getDate(){
  return new Date().toISOString().substring(0, 10);
}

/* GET home page. */
router.get(['/', '/rep'], async function(req, res, next) {
  const date = getDate();

  try {
    // Fetch APENAS de recursos e utilizadores (removido o /api/posts)
    const headers = authHeaders(req)
    const [recursosResp, usersResp] = await Promise.all([
      axios.get(`${API_URL}/api/resources?sort=dataRegisto&order=desc`, { headers }).catch(() => ({ data: [] })),
      axios.get(`${API_URL}/api/users`, { headers }).catch(() => ({ data: [] }))
    ]);

    const recursos = recursosResp.data || [];
    const users = usersResp.data || [];

    // Recursos mais recentes (limit 6)
    const recentResources = recursos.slice(0, 6);

    // Top 3 recursos mais bem classificados (usando a propriedade classificacaoMedia)
    const topRecs = [...recursos].sort((a, b) => (b.classificacaoMedia || 0) - (a.classificacaoMedia || 0)).slice(0, 3);

    // 💡 Extrair TODAS as avaliações guardadas dentro dos recursos
    let allReviews = [];
    recursos.forEach(r => {
      if (r.avaliacoes && r.avaliacoes.length > 0) {
        r.avaliacoes.forEach(a => {
          allReviews.push({
            user: a.user,
            recursoId: r._id,
            recursoTitulo: r.titulo,
            valor: a.valor,
            data: a.data
          });
        });
      }
    });

    // Ordenar as avaliações da mais recente para a mais antiga e cortar nas top 5
    allReviews.sort((a, b) => new Date(b.data) - new Date(a.data));
    const recentAvaliacoes = allReviews.slice(0, 5);

    // Noticias: novos recursos (pendentes ou recentes) e novos utilizadores
    const newSubmissions = recursos.filter(r => r.estado === 'pendente');
    const recentUsers = [...users].sort((a, b) => (b.dataRegisto || '').localeCompare(a.dataRegisto || '')).slice(0, 3);

    // Estatisticas atualizadas (sem o "totalPosts")
    const stats = {
      totalRecursos: recursos.length,
      totalUsers: users.length,
      aprovados: recursos.filter(r => r.estado === 'aprovado').length,
      pendentes: recursos.filter(r => r.estado === 'pendente').length
    };

    // Map de user IDs para nomes 
    const userMap = {};
    users.forEach(u => { userMap[u._id] = u.nome; });

    // Map de resource IDs para titulos
    const resourceMap = {};
    recursos.forEach(r => { resourceMap[r._id] = r.titulo; });

    res.render('index', {
      title: 'RepositoriUM',
      date,
      recentAvaliacoes, // Enviamos recentAvaliacoes em vez de recentPosts
      recentResources,
      topRecs,
      newSubmissions,
      recentUsers,
      stats,
      userMap,
      resourceMap
    });
  } catch (error) {
    console.error('Erro ao carregar homepage:', error.message);
    res.render('index', {
      title: 'RepositoriUM',
      date,
      recentAvaliacoes: [], // Corrigido aqui
      recentResources: [],
      topRecs: [], // Corrigido de topPosts para topRecs
      newSubmissions: [],
      recentUsers: [],
      stats: { totalRecursos: 0, totalUsers: 0, aprovados: 0, pendentes: 0 }, // Removido totalPosts
      userMap: {},
      resourceMap: {}
    });
  }
});

// ===== Admin: Exportar/Importar tudo =====

// Download de um ZIP com a BD (data.json) + a árvore uploads/
router.get('/admin/export', requireLevel('administrador'), async (req, res) => {
  try {
    const response = await axios.get(`${API_URL}/api/export`, {
      headers: authHeaders(req),
      responseType: 'stream'
    })
    const filename = `plataforma-export-${getDate()}.zip`
    res.setHeader('Content-Type', 'application/zip')
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`)
    response.data.pipe(res)
  } catch (error) {
    console.error('Erro ao exportar:', error.response?.data || error.message)
    return res.status(500).render('error', {
      message: 'Falhou a exportação dos dados.',
      error: { status: 500 }
    })
  }
})

// Upload de um ZIP (data.json + uploads/) ou JSON (compatibilidade) para repor estado
router.post('/admin/import', requireLevel('administrador'), upload.single('ficheiro'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).render('error', {
        message: 'Selecione um ficheiro .zip ou .json para importar.',
        error: { status: 400 }
      })
    }

    // Reencaminhar como multipart para a data-api
    const fd = new FormData()
    fd.append(
      'ficheiro',
      new Blob([req.file.buffer], { type: req.file.mimetype || 'application/octet-stream' }),
      req.file.originalname
    )

    await axios.post(`${API_URL}/api/export`, fd, {
      headers: authHeaders(req),
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    })
    return res.redirect('/')
  } catch (error) {
    console.error('Erro ao importar:', error.response?.data || error.message)
    return res.status(500).render('error', {
      message: 'Falhou a importação dos dados.',
      error: { status: 500 }
    })
  }
})

module.exports = router;