const express = require('express')
const router = express.Router()
const multer = require('multer')
const { authHeaders } = require('../middleware/auth')

const API_URL = `${process.env.DATA_API_URL}/api`
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024 } })

// Constrói um FormData reencaminhável a partir dos campos e ficheiros recebidos
function buildForwardForm(body, files) {
    const fd = new FormData()
    for (const [key, value] of Object.entries(body || {})) {
        if (value === undefined || value === null) continue
        if (typeof value === 'object') fd.append(key, JSON.stringify(value))
        else fd.append(key, String(value))
    }
    for (const file of files || []) {
        fd.append('files', new Blob([file.buffer], { type: file.mimetype }), file.originalname)
    }
    return fd
}

router.get('/', async (req, res) => {
    try {
        const params = new URLSearchParams()
        if (req.query.tipo) params.append('tipo', req.query.tipo)
        if (req.query.sort) params.append('sort', req.query.sort)
        if (req.query.order) params.append('order', req.query.order)

        const response = await fetch(`${API_URL}/resources?${params}`, {
            headers: authHeaders(req)
        })
        const data = await response.json()
        res.render('resources/resources_list', { resources: data, user: req.user, query: req.query })
    } catch (e) {
        console.log('ERRO NA LISTAGEM:', e.message)
        res.status(500).send(e.message)
    }
})

// GET /new mostra a página de upload (apenas produtor/administrador)
router.get('/new', async (req, res) => {
    if (!req.user || !['produtor', 'administrador'].includes(req.user.nivel)) {
        return res.status(403).render('error', {
            message: 'Apenas produtores podem submeter recursos.',
            error: { status: 403 }
        })
    }

    try {
        let filiacoes = [];
        let myFiliacao = null;

        // Se for admin, carrega todas as filiações para o dropdown
        if (req.user.nivel === 'administrador') {
            const filiacoesResp = await fetch(`${API_URL}/filiacoes?ativa=true`, { headers: authHeaders(req) });
            filiacoes = await filiacoesResp.json();
        } else {
            // Se for produtor, carrega a própria filiação (como segurança)
            const userResp = await fetch(`${API_URL}/users/${req.user.sub}`, { headers: authHeaders(req) });
            const userData = await userResp.json();
            if (userData && userData.filiacao) {
               myFiliacao = userData.filiacao;
            }
        }

        res.render('resources/resource_upload', { 
            user: req.user, 
            filiacoes: filiacoes, 
            myFiliacao: myFiliacao 
        })
    } catch (e) {
        res.status(500).render('error', { message: 'Erro ao carregar formulário' })
    }
})
// GET /:id/edit mostra página de edição do recurso
router.get('/:id/edit', async (req, res) => {
    try {
        let filiacoes = [];
        let myFiliacao = null;

        const responsePromise = fetch(`${API_URL}/resources/${req.params.id}`, { headers: authHeaders(req) });
        
        if (req.user.nivel === 'administrador') {
            const filiacoesPromise = fetch(`${API_URL}/filiacoes?ativa=true`, { headers: authHeaders(req) });
            const [response, filiacoesResp] = await Promise.all([responsePromise, filiacoesPromise]);
            const data = await response.json();
            filiacoes = await filiacoesResp.json();
            res.render('resources/resource_upload', { resource: data, mode: 'edit', user: req.user, filiacoes: filiacoes });
        } else {
             const userPromise = fetch(`${API_URL}/users/${req.user.sub}`, { headers: authHeaders(req) });
             const [response, userResp] = await Promise.all([responsePromise, userPromise]);
             const data = await response.json();
             const userData = await userResp.json();
             if (userData && userData.filiacao) myFiliacao = userData.filiacao;
             res.render('resources/resource_upload', { resource: data, mode: 'edit', user: req.user, myFiliacao: myFiliacao });
        }

    } catch (e) {
        res.status(500).render('error', { message: e.message })
    }
})

// GET /:id/export envia o ZIP DIP
router.get('/:id/export', async (req, res) => {
    try {
        const response = await fetch(`${API_URL}/resources/${req.params.id}/export`, {
            headers: authHeaders(req)
        })

        if (!response.ok) {
            const erro = await response.json().catch(() => ({ erro: 'Erro a obter recurso' }))
            return res.status(response.status).render('error', {
                message: erro.erro || 'Erro ao gerar DIP',
                error: { status: response.status }
            })
        }

        res.setHeader('Content-Type', 'application/zip')
        res.setHeader('Content-Disposition', `attachment; filename=DIP-${req.params.id}.zip`)

        const buffer = await response.arrayBuffer()
        res.send(Buffer.from(buffer))
    } catch (e) {
        res.status(500).render('error', { message: e.message })
    }
})

router.get('/:id', async (req, res) => {
    try {
        const response = await fetch(`${API_URL}/resources/${req.params.id}`, {
            headers: authHeaders(req)
        })
        if (response.status === 403) {
            return res.status(403).render('error', {
                message: 'Sem permissões para aceder a este recurso.',
                error: { status: 403 }
            })
        }
        if (response.status === 404) {
            return res.status(404).render('error', {
                message: 'Este recurso já não se encontra disponível.',
                error: { status: 404 }
            })
        }
        const data = await response.json()
        res.render('resources/resources_detail', { resource: data, user: req.user })
    } catch (e) {
        res.status(500).render('error', { message: e.message })
    }
})

router.delete('/:id', async (req, res) => {
    try {
        await fetch(`${API_URL}/resources/${req.params.id}`, {
            method: 'DELETE',
            headers: authHeaders(req)
        })
        res.json({ success: true })
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})

router.post('/', upload.array('files', 10), async (req, res) => {
    try {
        const fd = buildForwardForm(req.body, req.files)
        const response = await fetch(`${API_URL}/resources/register`, {
            method: 'POST',
            headers: authHeaders(req),
            body: fd
        })
        const data = await response.json().catch(() => ({}))
        res.status(response.status).json(data)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})

router.put('/:id', upload.array('files', 10), async (req, res) => {
    try {
        const hasFiles = req.files && req.files.length > 0
        const init = { method: 'PATCH', headers: authHeaders(req) }
        if (hasFiles) {
            init.body = buildForwardForm(req.body, req.files)
        } else {
            init.headers = { ...init.headers, 'Content-Type': 'application/json' }
            init.body = JSON.stringify(req.body)
        }
        const response = await fetch(`${API_URL}/resources/${req.params.id}`, init)
        const data = await response.json().catch(() => ({}))
        res.status(response.status).json(data)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})


// Aprovar / rejeitar (apenas admin — a data-api faz a verificação)
router.post('/:id/aprovar', async (req, res) => {
    try {
        const response = await fetch(`${API_URL}/resources/${req.params.id}/aprovar`, {
            method: 'PATCH',
            headers: authHeaders(req)
        })
        const data = await response.json().catch(() => ({}))
        res.status(response.status).json(data)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})

// Avaliar recurso (estrelas)
router.post('/:id/avaliar', async (req, res) => {
    try {
        const response = await fetch(`${API_URL}/resources/${req.params.id}/avaliar`, {
            method: 'POST',
            headers: { ...authHeaders(req), 'Content-Type': 'application/json' },
            body: JSON.stringify({ valor: req.body.valor })
        })
        const data = await response.json().catch(() => ({}))
        res.status(response.status).json(data)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})

router.delete('/:id/avaliar', async (req, res) => {
    try {
        const response = await fetch(`${API_URL}/resources/${req.params.id}/avaliar`, {
            method: 'DELETE',
            headers: authHeaders(req)
        })
        const data = await response.json().catch(() => ({}))
        res.status(response.status).json(data)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})

router.post('/:id/rejeitar', async (req, res) => {
    try {
        const response = await fetch(`${API_URL}/resources/${req.params.id}/rejeitar`, {
            method: 'PATCH',
            headers: authHeaders(req)
        })
        const data = await response.json().catch(() => ({}))
        res.status(response.status).json(data)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
})

module.exports = router
