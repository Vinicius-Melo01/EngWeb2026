require('dotenv').config()
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var postsRouter = require('./routes/posts');
var commentsRouter = require('./routes/comments');
const resourcesRouter = require('./routes/resources')
const filiacoesRouter = require('./routes/filiacoes')
const { attachUser, requireAuth } = require('./middleware/auth')

const swaggerUi = require('swagger-ui-express')
const swaggerDocument = require('./swagger.json')

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Lê cookie JWT e popula req.user / res.locals.user para todas as views
app.use(attachUser)

// Documentação Swagger (público)
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument))

app.use('/', indexRouter);
// As páginas internas (/rep/*) requerem login
app.use('/rep', requireAuth)
app.use('/', usersRouter);
app.use('/', postsRouter);
app.use('/', commentsRouter);
app.use('/rep/resources', resourcesRouter)
app.use('/rep/filiacoes', filiacoesRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
