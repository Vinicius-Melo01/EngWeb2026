#!/bin/bash

echo "A importar dados para a base de dados..."
mongoimport --db plataformaEW26 --collection utilizadores --file /docker-entrypoint-initdb.d/utilizadores.json --jsonArray
mongoimport --db plataformaEW26 --collection recursos --file /docker-entrypoint-initdb.d/recursos.json --jsonArray
mongoimport --db plataformaEW26 --collection posts --file /docker-entrypoint-initdb.d/posts.json --jsonArray
mongoimport --db plataformaEW26 --collection comentarios --file /docker-entrypoint-initdb.d/comentarios.json --jsonArray
mongoimport --db plataformaEW26 --collection filiacao --file /docker-entrypoint-initdb.d/filiacoes.json --jsonArray

echo "Setup da base de dados concluído! (índices criados pelo Mongoose no arranque da data-api)"
