const mongoose = require('mongoose')

const filiacaoSchema = new mongoose.Schema({
    _id: { type: String, required: true },
    nome: { type: String, required: true },
    tipo: {
        type: String,
        enum: ['ESTUDANTE', 'DOCENTE', 'INVESTIGADOR'],
        default: 'ESTUDANTE'
    },
    instituicao: { type: String, required: true },
    curso: { type: String, required: true },
    ativa: { type: Boolean, default: true }
}, {
    versionKey: false
})

filiacaoSchema.index({ nome: 1 })
filiacaoSchema.index({ instituicao: 1 })
filiacaoSchema.index({ ativa: 1 })
filiacaoSchema.index({ tipo: 1 })

const Filiacao = mongoose.model('Filiacao', filiacaoSchema, 'filiacao')

module.exports = Filiacao