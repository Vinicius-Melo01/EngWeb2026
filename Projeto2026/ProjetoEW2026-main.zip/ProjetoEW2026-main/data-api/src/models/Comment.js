const mongoose = require('mongoose')

const commentSchema = new mongoose.Schema({
    _id: { type: String, required: true },
    criador: { type: String, ref: 'utilizadores' },
    post: { type: String, ref: 'posts' },
    data: { 
        type: String, 
        default: () => new Date().toISOString().substring(0,10)
    },
    texto: { type: String, required: true },
    avaliacao: {
        type: Number,
        required: true,
        default: 3.0,
        min: 0.5,
        max: 5,
        validate: {
            validator: function(v) {
                if (!v) return true; 
                return (v * 2) % 1 === 0 && v >= 0.5 && v <= 5;
            },
            message: 'Avaliação deve estar entre 0.5 e 5 em incrementos de 0.5'
        }
    }
}, { versionKey: false })

commentSchema.index({ post: 1 })
commentSchema.index({ data: 1 })

const Comment = mongoose.model('comentarios', commentSchema)
module.exports = Comment