const mongoose = require('mongoose')

const postSchema = new mongoose.Schema({
    _id: { type: String, required: true },
    titulo: { type: String, required: true },
    produtor: { type: String, ref: 'utilizadores' },
    dataCriacao: { 
        type: String, 
        default: () => new Date().toISOString().substring(0,10)
    },
    texto: { type: String, required: true },
    comentarios: { 
        type: [String], 
        ref: 'comentarios', 
        default: [] 
    },
    dados: { type: String, ref: 'recursos', default: null},
    classificacaoMedia: { type: Number, default: 2.5 }
}, { versionKey: false })

postSchema.index({ dados: 1 })
postSchema.index({ produtor: 1 })
postSchema.index({ dataCriacao: -1 })

const Post = mongoose.model('posts', postSchema)
module.exports = Post