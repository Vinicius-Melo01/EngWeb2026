const mongoose = require('mongoose')

const avaliacaoSchema = new mongoose.Schema({
    user: { type: String, ref: 'utilizadores', required: true },
    valor: {
        type: Number,
        required: true,
        min: 0.5,
        max: 5,
        validate: {
            validator: v => (v * 2) % 1 === 0 && v >= 0.5 && v <= 5,
            message: 'Avaliação deve estar entre 0.5 e 5 em incrementos de 0.5'
        }
    },
    data: { type: String, default: () => new Date().toISOString().substring(0, 10) }
}, { _id: false })

const resourceSchema = new mongoose.Schema({
    _id: { type: String, required: true },
    produtor: { type: String, ref: 'User' },
    tipo: { type: String, required: true },
    titulo: { type: String, required: true },
    subtitulo: { type: String },
    path: { type: String },
    hashtags: { type: [String], default: [] },
    ativo: { type: Boolean, default: true },
    estado: {
        type: String,
        enum: ['pendente', 'aprovado', 'rejeitado'],
        default: 'pendente'
    },
    visibilidade: {
        status: {
            type: String,
            enum: ['PUBLIC', 'PRIVATE', 'RESTRICTED'],
            required: true,
            default: 'PUBLIC'
        },
        scope: {
          filiacao: { type: String, ref: 'Filiacao' }
        }
    },
    avaliacoes: { type: [avaliacaoSchema], default: [] },
    classificacaoMedia: { type: Number, default: 0 },
    numAvaliacoes: { type: Number, default: 0 }
}, {
    versionKey: false,
    timestamps: { createdAt: 'dataRegisto', updatedAt: 'dataUltimaAlteracao' }
})

resourceSchema.index({ produtor: 1 })
resourceSchema.index({ tipo: 1 })
resourceSchema.index({ hashtags: 1 })
resourceSchema.index({ titulo: 'text' })
resourceSchema.index({ estado: 1 })
resourceSchema.index({ classificacaoMedia: -1 })

const Resource = mongoose.model('Resource', resourceSchema, 'recursos')

module.exports = Resource
