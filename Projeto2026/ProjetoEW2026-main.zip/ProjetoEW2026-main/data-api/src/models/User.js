const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
    _id: { type: String, required: true },
    nome: { type: String, required: true },
    email: { type: String, required: true },
    filiacao: { type: String, ref: 'Filiacao', required: true },
    nivel: {
        type: String,
        enum: ['produtor', 'consumidor', 'administrador'],
        required: true
    },
    password: { type: String, required: true },
    ativo : {type: Boolean, default: true}
}, {
    versionKey: false,
    timestamps: { createdAt: 'dataRegisto', updatedAt: 'dataUltimoAcesso' }
})

userSchema.index({ email: 1 }, { unique: true })
userSchema.index({ nome: 1 })
userSchema.index({ nivel: 1 })

const User = mongoose.model('utilizadores', userSchema)
module.exports = User
