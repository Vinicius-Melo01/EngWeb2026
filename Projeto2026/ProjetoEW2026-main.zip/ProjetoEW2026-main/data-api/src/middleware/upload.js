const multer = require('multer');
const path = require('path')
const fs = require('fs');


// Single file storage
const resourceStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        // tipo vem no body: "datasets/json", "programa/python", "texto/fichas", etc.
        const type = req.body.tipo || 'others'
        const dir = path.join(__dirname, '../../uploads', type)
        fs.mkdirSync(dir, { recursive: true })
        cb(null, dir)
    },
    filename: function (req, file, cb) {
        // Guarda o ficheiro com o nome original + timestamp para evitar sobreposições
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.originalname + ' (' + uniqueSuffix + ')');
    }
});

// SIP (com BagIt) upload para a pasta temprária sip_temp/ -> Evita gravar ZIPs de tamanho elevado em RAM enquanto esperam a validação 
// Antes de fazermos a validação dos SIPs, é necessário a receção completa do ZIP
// Desta forma, o servidor não consome memória excessiva enquanto aguarda a receção do ZIP
const sipStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dest = path.join(__dirname, '../../uploads/sip_temp')
        fs.mkdirSync(dest, { recursive: true })
        cb(null, dest)
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname)
    }
})


const uploadResource = multer({
    storage: resourceStorage,
    limits: { fileSize: 100 * 1024 * 1024 }  // 100MB de limite
})

const uploadSIP = multer({ 
    storage: sipStorage,
    limits: { fileSize: 500 * 1024 * 1024 }, // 500MB para ZIPs
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
            cb(null, true)
        } else {
            cb(new Error('SIP deve ser um ficheiro ZIP'), false)
        }
    }
})

module.exports = { uploadResource, uploadSIP }