const jwt = require('jsonwebtoken')

const JWT_SECRET = process.env.JWT_SECRET

// Middleware que tenta extrair e verificar o JWT do cabeçalho Authorization.
// Se válido, popula req.user com as claims (sub, email, nome, nivel).
// Se inválido ou ausente, deixa req.user a undefined (não bloqueia o pedido).
function attachUser(req, res, next) {
    const auth = req.headers.authorization || ''
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : null

    if (!token) {
        req.user = null
        return next()
    }

    jwt.verify(token, JWT_SECRET, (err, payload) => {
        if (err) {
            req.user = null
        } else {
            req.user = payload
        }
        next()
    })
}

// Bloqueia o pedido se não houver utilizador autenticado.
function requireAuth(req, res, next) {
    if (!req.user) {
        return res.status(401).json({ erro: 'Token de autenticação ausente ou inválido.' })
    }
    next()
}

// Restringe o acesso a utilizadores com um dos níveis indicados.
function requireLevel(...levels) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ erro: 'Token de autenticação ausente ou inválido.' })
        }
        if (!levels.includes(req.user.nivel)) {
            return res.status(403).json({ erro: 'Sem permissões para esta operação.' })
        }
        next()
    }
}

module.exports = { attachUser, requireAuth, requireLevel }
