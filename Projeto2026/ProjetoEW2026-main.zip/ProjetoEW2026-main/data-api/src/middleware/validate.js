const AdmZip = require('adm-zip')
const crypto = require('crypto')

exports.validateSIP = (req, res, next) => {
    if (!req.file) {
        return res.status(400).json({
            erro: 'Falha na validação do SIP',
            relatorio: {
                valido: false,
                motivo: 'Ficheiro SIP não enviado.',
                timestamp: new Date().toISOString()
            }
        })
    }

    try {
        const zip = new AdmZip(req.file.path)
        const entries = zip.getEntries()
        const entryNames = entries.map(e => e.entryName)

        // 1. Procurar manifesto BagIt (manifest-md5.txt, manifest-sha256.txt, etc.)
        const manifestName = entryNames.find(n =>
            n.match(/manifest-(md5|sha256|sha512)\.txt$/)
        )

        if (!manifestName) {
            return res.status(400).json({
                erro: 'Falha na validação do SIP',
                relatorio: {
                    valido: false,
                    ficheiro: req.file.originalname,
                    motivo: 'Falta manifest-{algoritmo}.txt (formato BagIt obrigatório)',
                    ficheirosNoZip: entryNames,
                    timestamp: new Date().toISOString()
                }
            })
        }

        // 2. Extrair algoritmo do nome do manifesto
        const algo = manifestName.match(/manifest-(md5|sha256|sha512)/)[1]

        // 3. Ler manifesto e validar checksums de cada ficheiro listado
        const manifest = zip.readAsText(manifestName)
        const erros = []

        for (const line of manifest.trim().split('\n')) {
            if (!line.trim()) continue
            const [expectedHash, ...fileParts] = line.trim().split(/\s+/)
            const filePath = fileParts.join(' ')
            if (!filePath) continue

            const entry = entries.find(e => e.entryName === filePath)
            if (!entry) {
                erros.push(`Ficheiro em falta no ZIP: ${filePath}`)
                continue
            }

            const actualHash = crypto
                .createHash(algo)
                .update(entry.getData())
                .digest('hex')

            if (actualHash !== expectedHash) {
                erros.push(`Checksum inválido para ${filePath}: esperado ${expectedHash}, obtido ${actualHash}`)
            }
        }

        if (erros.length > 0) {
            return res.status(400).json({
                erro: 'Falha na validação do SIP',
                relatorio: {
                    valido: false,
                    ficheiro: req.file.originalname,
                    algoritmo: algo,
                    erros: erros,
                    totalFicheiros: entries.length,
                    totalErros: erros.length,
                    timestamp: new Date().toISOString()
                }
            })
        }

        // 4. Guardar info extraída para o controller usar
        req.sipEntries = entries
        req.sipZip = zip
        req.sipAlgo = algo

        next()
    } catch (error) {
        return res.status(400).json({
            erro: 'Falha na validação do SIP',
            relatorio: {
                valido: false,
                ficheiro: req.file ? req.file.originalname : 'desconhecido',
                motivo: error.message,
                timestamp: new Date().toISOString()
            }
        })
    }
}
