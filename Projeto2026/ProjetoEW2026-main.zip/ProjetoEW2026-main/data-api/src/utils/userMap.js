const User = require('../models/User')

async function getUsersByIds(ids) {
    const uniqueIds = [...new Set(ids.filter(Boolean))]
    const users = await User.find({ _id: { $in: uniqueIds } }).select('_id nome').lean()
    return Object.fromEntries(users.map(u => [u._id, u.nome]))
}

async function getUserById(id) {
    return await User.findById(id).select('_id nome').lean()
}

module.exports = { getUsersByIds, getUserById }