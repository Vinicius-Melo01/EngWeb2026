const User = require('../models/User')

/**
 * Constrói o filtro Mongo de visibilidade para resources conforme o user
 * Reutiliza a lógica do resourceController
 * Regras:
 *   - administrador: vê tudo (sem filtro)
 *   - produtor: vê os seus próprios recursos (qualquer estado/visibilidade) +
 *               aprovados PUBLIC + aprovados RESTRICTED na sua filiação
 *   - consumidor: vê aprovados PUBLIC + aprovados RESTRICTED na sua filiação
 *   - sem auth: apenas PUBLIC aprovados
 */
async function buildVisibilityFilter(user) {
    if (user && user.nivel === 'administrador') return {} // Vê tudo

    const baseClauses = [{ 'visibilidade.status': 'PUBLIC', estado: 'aprovado' }]

    if (user && user.sub) {
        const dbUser = await User.findById(user.sub).select('filiacao').lean()
        if (dbUser?.filiacao) {
            baseClauses.push({
                'visibilidade.status': 'RESTRICTED',
                'visibilidade.scope.filiacao': dbUser.filiacao.toString(),
                estado: 'aprovado'
            })
        }
        if (user.nivel === 'produtor') {
            baseClauses.push({ produtor: user.sub })
        }
    }

    return { 
        $and: [
            { ativo: true }, 
            { $or: baseClauses }
        ]
    }
}

module.exports = { buildVisibilityFilter }