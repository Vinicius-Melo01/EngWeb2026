const Comment = require('../models/Comment')

async function updateAvgRating(post, Comment) {
    const comments = await Comment.find({ post: post._id })
    post.classificacaoMedia = comments.length === 0
        ? 0
        : parseFloat((comments.reduce((sum, c) => sum + c.avaliacao, 0) / comments.length).toFixed(1))
    await post.save()
}

module.exports = { updateAvgRating }