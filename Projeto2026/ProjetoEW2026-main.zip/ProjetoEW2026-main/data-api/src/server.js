require('dotenv').config()
const express = require('express')
const connectDB = require('./config/db')
const logger = require('morgan')
const app = express()

const swaggerUi = require('swagger-ui-express')
const swaggerDocument = require('./swagger.json')

const { attachUser } = require('./middleware/auth')
const router = require('./routes/index')


app.use(express.json())
app.use(logger('dev'))
app.use(express.urlencoded({ extended: true }))
app.use(attachUser)


connectDB()

const PORT = process.env.PORT || 3001

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument))
app.use('/', router)

app.use((req, res) => {
    res.status(404).json({ erro: 'Rota não encontrada na API de Dados.' });
});

app.listen(PORT, () => {
    console.log(`API de dados à escuta na porta ${PORT}...`)
    console.log(`📄 Documentação Swagger disponível em: http://localhost:${PORT}/api-docs`)
})