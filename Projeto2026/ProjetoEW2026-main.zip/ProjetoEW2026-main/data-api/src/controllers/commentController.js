const Comment = require('../models/Comment');
const { getUsersByIds } = require('../utils/userMap')

exports.listComments = async (req, res) => {
    try {
        let filter = {};
        
        if(req.query.criador) filter.criador = req.query.criador;
        if(req.query.post) filter.post = req.query.post;
        if(req.query.data) filter.data = req.query.data;
        if(req.query.texto) filter.texto = { $regex: req.query.texto, $options: 'i' };

        const sort = req.query.sort || 'data'; 
        const order = req.query.order === 'desc' ? -1 : 1;

        const comments = await Comment.find(filter).sort({ [sort]: order }).lean()

        const criadorMap = await getUsersByIds(comments.map(c => c.criador))

        const result = comments.map(c => ({
            ...c,
            nomeCriador: criadorMap[c.criador] ?? null
        }))

        res.status(200).json(result)
    } catch (error) {
        res.status(500).json({ message: "Erro na listagem de comentários", description: error.message });
    }
};

exports.fetchComment = async (req, res) => {
    try {
        const { id } = req.params; 

        const comment = await Comment.findById(id);
        
        if(!comment){
            return res.status(404).json({
                message: "Comentário não encontrado na base de dados",
                description: `O ID ${id} não existe na base de dados`
            });
        }
        res.status(200).json(comment);
    } catch (error) {
        res.status(500).json({ message: "Erro na pesquisa do comentário", description: error.message });
    }
};

exports.createComment = async (req, res) => {
    try {
        const newComment = new Comment({
            ...req.body,
            criador: req.user.sub
        });
        await newComment.save();
        
        res.status(201).json(newComment);
    } catch (error) {
        res.status(400).json({ mensagem: "Erro ao registar comentário", erro: error.message });
    }
};

exports.updateComment = async (req, res) => {
    try {
        const { id } = req.params;

        const comment = await Comment.findByIdAndUpdate(id, req.body, { new: true }).lean();
        
        if (!comment) return res.status(404).json({ mensagem: "Comentário não encontrado." });
        
        return res.status(200).json(comment);
    } catch (error) {
        return res.status(400).json({ error: error.message });
    }
};

exports.deleteComment = async (req, res) => {
    try {
        const { id } = req.params;
        
        const deletedComment = await Comment.findByIdAndDelete(id);
        
        if (!deletedComment) return res.status(404).json({ mensagem: "Comentário não encontrado." });
        
        return res.status(204).send();
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};