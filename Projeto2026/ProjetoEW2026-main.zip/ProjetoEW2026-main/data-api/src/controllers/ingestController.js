const Resource = require('../models/Resource')
const path = require('path')
const fs = require('fs')

// POST /api/ingest — Recebe SIP (ZIP BagIt) já validado e cria recurso
exports.ingestSIP = async (req, res) => {
    try {
        const { titulo, tipo, produtor, visibilidade, subtitulo, hashtags } = req.body
        const zip = req.sipZip

        const destBase = path.join(__dirname, '../../uploads', tipo || 'outros')
        fs.mkdirSync(destBase, { recursive: true })

        const dataEntries = zip.getEntries().filter(e =>
            e.entryName.startsWith('data/') && !e.isDirectory
        )

        const savedPaths = []
        for (const entry of dataEntries) {
            const filename = Date.now() + '-' + path.basename(entry.entryName)
            const destPath = path.join(destBase, filename)
            fs.writeFileSync(destPath, entry.getData())
            savedPaths.push(path.relative('/app', destPath))
        }

        const resource = new Resource({
            _id: `REC-${Date.now()}`,
            produtor: produtor,
            tipo: tipo || 'outros',
            titulo: titulo,
            subtitulo: subtitulo || null,
            path: savedPaths.join(';'),
            visibilidade: {
                status: visibilidade || 'PUBLIC'
            },
            hashtags: hashtags ? (Array.isArray(hashtags) ? hashtags : hashtags.split(',')) : [],
            estado: 'pendente'
        })
        await resource.save()

        fs.unlinkSync(req.file.path)

        res.status(201).json({
            mensagem: 'SIP ingerido com sucesso. Recurso aguarda aprovação.',
            recurso: resource
        })
    } catch (error) {

        if (req.file && req.file.path && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path)
        }
        res.status(500).json({ erro: 'Erro na ingestão do SIP', detalhes: error.message })
    }
}
