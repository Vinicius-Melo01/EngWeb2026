const Resource = require('../models/Resource')
const path = require('path')
const fs = require('fs')
const archiver = require('archiver')
const crypto = require('crypto')
const { buildVisibilityFilter } = require('../utils/visibilityFilter')

// GET /api/resources/:id/export — Gera DIP (ZIP com metadados + ficheiros + manifesto BagIt)
exports.exportDIP = async (req, res) => {
    try {
        const resource = await Resource.findById(req.params.id).lean()

        if (!resource) {
            return res.status(404).json({ erro: 'Recurso não encontrado.' })
        }

        if (resource.estado !== 'aprovado') {
            return res.status(403).json({ erro: 'Recurso não está aprovado para disseminação.' })
        }

        // Verifica se o user pode aceder ao recurso (consoante o seu nivel/filiacao)
        const visFilter = await buildVisibilityFilter(req.user)
        const allowed = await Resource.findOne({ $and: [{ _id: req.params.id }, visFilter] }).select('_id').lean()
        if (!allowed) {
            return res.status(403).json({ erro: 'Sem permissões para descarregar este recurso.' })
        }

        const archive = archiver('zip', { zlib: { level: 9 } })

        res.setHeader('Content-Type', 'application/zip')
        res.setHeader('Content-Disposition', `attachment; filename=DIP-${resource._id}.zip`)

        archive.on('error', (err) => {
            res.status(500).json({ erro: 'Erro ao gerar DIP', detalhes: err.message })
        })

        archive.pipe(res)

        // 1. Metadados do recurso como JSON
        archive.append(JSON.stringify(resource, null, 2), { name: 'metadata.json' })

        // 2. Ficheiros do recurso + gerar manifesto SHA256
        const manifestLines = []
        const files = (resource.path || '').split(';').filter(Boolean)

        // Possíveis locais onde o ficheiro pode estar (consoante como o path foi guardado)
        const baseDirs = [
            path.join(__dirname, '../../'),       // /app/  -> uploads/...
            path.join(__dirname, '../../uploads'),// /app/uploads -> programs/...
            '/app',                                // path absoluto no container
            '/'                                    // fallback absoluto
        ]

        for (const filePath of files) {
            let abs = null
            for (const base of baseDirs) {
                const candidate = path.isAbsolute(filePath) ? filePath : path.join(base, filePath)
                if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
                    abs = candidate
                    break
                }
            }

            if (abs) {
                const fileName = path.basename(abs)
                archive.file(abs, { name: 'data/' + fileName })

                const hash = crypto.createHash('sha256')
                    .update(fs.readFileSync(abs))
                    .digest('hex')
                manifestLines.push(`${hash}  data/${fileName}`)
            } else {
                console.warn(`[exportDIP] Ficheiro não encontrado: ${filePath}`)
            }
        }

        // 3. Manifesto BagIt
        if (manifestLines.length > 0) {
            archive.append(manifestLines.join('\n'), { name: 'manifest-sha256.txt' })
        }

        // 4. bagit.txt (identificador de versão BagIt)
        archive.append('BagIt-Version: 1.0\nTag-File-Character-Encoding: UTF-8\n', { name: 'bagit.txt' })

        await archive.finalize()
    } catch (error) {
        res.status(500).json({ erro: 'Erro ao gerar DIP', detalhes: error.message })
    }
}

// Pasta raiz onde os ficheiros físicos vivem (no container = /app/uploads)
const UPLOADS_ROOT = path.join(__dirname, '../../uploads')

// GET /api/export — Exporta tudo num ZIP: data.json + árvore uploads/
exports.exportAll = async (req, res) => {
    try {
        const User = require('../models/User')
        const Post = require('../models/Post')
        const Comment = require('../models/Comment')
        const Filiacao = require('../models/Filiacao')

        const [utilizadores, recursos, posts, comentarios, filiacoes] = await Promise.all([
            User.find({}).select('-password').lean(),
            Resource.find({}).lean(),
            Post.find({}).lean(),
            Comment.find({}).lean(),
            Filiacao.find({}).lean()
        ])

        const archive = archiver('zip', { zlib: { level: 9 } })
        const filename = `plataforma-export-${new Date().toISOString().slice(0, 10)}.zip`

        res.setHeader('Content-Type', 'application/zip')
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`)

        archive.on('warning', (err) => {
            console.warn('[exportAll] Aviso do archiver:', err.message)
        })

        archive.on('error', (err) => {
            console.error('[exportAll] Erro do archiver:', err)
            if (!res.headersSent) {
                res.status(500).json({ erro: 'Erro ao gerar ZIP', detalhes: err.message })
            }
        })

        archive.pipe(res)

        // 1) Conteúdo da BD em JSON
        const data = { utilizadores, recursos, posts, comentarios, filiacoes }
        archive.append(JSON.stringify(data, null, 2), { name: 'data.json' })

        // 2) Travessia de uploads/ — apenas ficheiros regulares, sem symlinks.
        // Evita erros de I/O em ficheiros especiais (sockets, FIFOs, links partidos).
        if (fs.existsSync(UPLOADS_ROOT) && fs.statSync(UPLOADS_ROOT).isDirectory()) {
            const stack = [UPLOADS_ROOT]
            let added = 0, skipped = 0
            while (stack.length) {
                const dir = stack.pop()
                let entries
                try {
                    entries = fs.readdirSync(dir, { withFileTypes: true })
                } catch (e) {
                    console.warn('[exportAll] readdir falhou:', dir, '-', e.message)
                    continue
                }
                for (const ent of entries) {
                    const full = path.join(dir, ent.name)
                    if (ent.isSymbolicLink()) { skipped++; continue }
                    if (ent.isDirectory()) { stack.push(full); continue }
                    if (!ent.isFile()) { skipped++; continue }
                    let buf
                    try {
                        buf = fs.readFileSync(full)
                    } catch (e) {
                        console.warn('[exportAll] read falhou:', full, '-', e.message)
                        skipped++
                        continue
                    }
                    const rel = path.relative(UPLOADS_ROOT, full).split(path.sep).join('/')
                    archive.append(buf, { name: 'uploads/' + rel })
                    added++
                }
            }
            console.log(`[exportAll] uploads/: ${added} ficheiros adicionados, ${skipped} saltados`)
        }

        await archive.finalize()
    } catch (error) {
        console.error('[exportAll] Erro:', error)
        if (!res.headersSent) {
            res.status(500).json({ erro: 'Erro na exportação', detalhes: error.message })
        }
    }
}

// POST /api/export — Importa dados (e ficheiros) para a plataforma.
// Aceita:
//   - multipart/form-data com campo 'ficheiro' (.zip com data.json + uploads/, ou .json simples)
//   - application/json com o objeto de dados directamente (compatibilidade)
exports.importAll = async (req, res) => {
    try {
        const User = require('../models/User')
        const Post = require('../models/Post')
        const Comment = require('../models/Comment')
        const Filiacao = require('../models/Filiacao')
        const AdmZip = require('adm-zip')

        let dados = null
        let ficheirosRestaurados = 0

        // Caso 1: ficheiro via multer
        if (req.file && req.file.buffer) {
            const buf = req.file.buffer
            const isZip = buf.length >= 2 && buf[0] === 0x50 && buf[1] === 0x4b // PK
            if (isZip) {
                const zip = new AdmZip(buf)
                const entries = zip.getEntries()

                // Extrair data.json
                const dataEntry = entries.find(e => e.entryName === 'data.json' || e.entryName.endsWith('/data.json'))
                if (!dataEntry) {
                    return res.status(400).json({ erro: 'O ZIP não contém data.json.' })
                }
                try {
                    dados = JSON.parse(dataEntry.getData().toString('utf-8'))
                } catch (_) {
                    return res.status(400).json({ erro: 'data.json não é um JSON válido.' })
                }

                // Extrair uploads/ para /app/uploads (preservando estrutura)
                fs.mkdirSync(UPLOADS_ROOT, { recursive: true })
                for (const entry of entries) {
                    if (entry.isDirectory) continue
                    if (!entry.entryName.startsWith('uploads/')) continue
                    const relativePath = entry.entryName.replace(/^uploads\//, '')
                    if (!relativePath) continue
                    const dest = path.join(UPLOADS_ROOT, relativePath)
                    // Defesa contra path traversal
                    if (!dest.startsWith(UPLOADS_ROOT + path.sep) && dest !== UPLOADS_ROOT) continue
                    fs.mkdirSync(path.dirname(dest), { recursive: true })
                    fs.writeFileSync(dest, entry.getData())
                    ficheirosRestaurados++
                }
            } else {
                // Não é ZIP — tentar como JSON
                try {
                    dados = JSON.parse(buf.toString('utf-8'))
                } catch (_) {
                    return res.status(400).json({ erro: 'O ficheiro enviado não é um ZIP nem um JSON válido.' })
                }
            }
        } else if (req.body && typeof req.body === 'object' && Object.keys(req.body).length > 0) {
            dados = req.body
        } else {
            return res.status(400).json({ erro: 'Nenhum dado recebido. Envie um ficheiro .zip ou .json.' })
        }

        const { utilizadores, recursos, posts, comentarios, filiacoes } = dados
        const resultado = { ficheirosRestaurados }

        // Filiações primeiro (users dependem)
        if (filiacoes && filiacoes.length > 0) {
            await Filiacao.insertMany(filiacoes, { ordered: false }).catch(() => {})
            resultado.filiacoes = filiacoes.length
        }
        if (utilizadores && utilizadores.length > 0) {
            await User.insertMany(utilizadores, { ordered: false }).catch(() => {})
            resultado.utilizadores = utilizadores.length
        }
        if (recursos && recursos.length > 0) {
            await Resource.insertMany(recursos, { ordered: false }).catch(() => {})
            resultado.recursos = recursos.length
        }
        if (posts && posts.length > 0) {
            await Post.insertMany(posts, { ordered: false }).catch(() => {})
            resultado.posts = posts.length
        }
        if (comentarios && comentarios.length > 0) {
            await Comment.insertMany(comentarios, { ordered: false }).catch(() => {})
            resultado.comentarios = comentarios.length
        }

        res.status(200).json({ mensagem: 'Importação concluída.', resultado })
    } catch (error) {
        console.error('[importAll] Erro:', error)
        res.status(500).json({ erro: 'Erro na importação', detalhes: error.message })
    }
}
