const Resource = require('../models/Resource')
const User = require('../models/User')
const { v4: uuidv4 } = require('uuid')
const path = require('path')
const { buildVisibilityFilter } = require('../utils/visibilityFilter')

exports.listResource = async (req, res) => {
    try {
        const visFilter = await buildVisibilityFilter(req.user)
        const queryFilter = {}

        if (req.query.tipo) queryFilter.tipo = req.query.tipo
        if (req.query.visibilidade) queryFilter['visibilidade.status'] = req.query.visibilidade

        const filter = Object.keys(queryFilter).length > 0
            ? { $and: [visFilter, queryFilter] }
            : visFilter

        const sort = {}
        if (req.query.sort) sort[req.query.sort] = req.query.order === 'desc' ? -1 : 1

        const recursos = await Resource.find(filter)
            .populate('visibilidade.scope.filiacao')
            .sort(sort)
            .lean()

        const userId = req.user && req.user.sub
        const result = recursos.map(r => {
            const minhaAvaliacao = userId && Array.isArray(r.avaliacoes)
                ? (r.avaliacoes.find(a => a.user === userId)?.valor ?? null)
                : null
            const { avaliacoes, ...rest } = r
            return { ...rest, minhaAvaliacao }
        })

        res.json(result)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
}

exports.fetchResource = async (req, res) => {
    try {
        const recurso = await Resource.findById(req.params.id)
            .populate('visibilidade.scope.filiacao')
            
        if (!recurso) {
            return res.status(404).json({ error: 'Recurso não encontrado' })
        }

        const isAdmin = req.user && req.user.nivel === 'administrador'

        if (!recurso.ativo && !isAdmin) {
            return res.status(404).json({ erro: 'Este recurso já não se encontra disponível.' })
        }

        const visFilter = await buildVisibilityFilter(req.user)
        const allowed = await Resource.findOne({ $and: [{ _id: req.params.id }, visFilter] }).select('_id').lean()
        if (!allowed) {
            return res.status(403).json({ erro: 'Sem permissões para aceder a este recurso.' })
        }

        const recursoObj = recurso.toObject()
        const userId = req.user && req.user.sub
        recursoObj.minhaAvaliacao = userId && Array.isArray(recursoObj.avaliacoes)
            ? (recursoObj.avaliacoes.find(a => a.user === userId)?.valor ?? null)
            : null
        delete recursoObj.avaliacoes

        res.json(recursoObj)
    } catch (e) {
        res.status(500).json({ error: e.message })
    }
}

exports.createResource = async (req, res) => {
    try {
        const data = { ...req.body };
        data._id = uuidv4()

        const files = req.files && req.files.length ? req.files : (req.file ? [req.file] : [])
        if (files.length) {
            const projectRoot = path.join(__dirname, '../../')
            data.path = files.map(f => path.relative(projectRoot, f.path)).join(';')
        }

        if (typeof data.visibilidade === 'string') {
            const trimmed = data.visibilidade.trim()
            if (trimmed.startsWith('{')) {
                try { data.visibilidade = JSON.parse(trimmed) }
                catch (_) { data.visibilidade = { status: trimmed } }
            } else {
                data.visibilidade = { status: trimmed }
            }
        } else if (!data.visibilidade) {
            data.visibilidade = { status: 'PUBLIC' }
        }

        if (data.visibilidade.status === 'RESTRICTED' && req.body.scopeFiliacao) {
            data.visibilidade.scope = { filiacao: req.body.scopeFiliacao };
        }

        if (data.visibilidade.status === 'RESTRICTED') {
            if (req.user && req.user.nivel !== 'administrador') {
                const dbUser = await User.findById(req.user.sub).select('filiacao').lean();
                if (!dbUser || !dbUser.filiacao) {
                    return res.status(400).json({ mensagem: "Não tem filiação associada — não pode criar recursos RESTRICTED." });
                }
                data.visibilidade.scope = { filiacao: dbUser.filiacao };
            } else if (!data.visibilidade.scope || !data.visibilidade.scope.filiacao) {
                return res.status(400).json({ mensagem: "Recursos RESTRICTED requerem um scope de filiação associado." });
            }
        } else {
            data.visibilidade.scope = undefined;
        }

        if (typeof data.hashtags === 'string') {
            data.hashtags = data.hashtags.split(',').map(s => s.trim()).filter(Boolean)
        }

        data.estado = 'pendente';
        data.produtor = req.user.sub;

        delete data.avaliacoes
        delete data.classificacaoMedia
        delete data.numAvaliacoes

        const newResource = new Resource(data);
        await newResource.save();
        res.status(201).json({ mensagem: "Recurso criado com sucesso! Aguarda aprovação.", id: newResource._id });
    } catch (error) {
        res.status(400).json({ mensagem: "Erro ao registar", erro: error.message });
    }
}

exports.updateResource = async (req, res) => {
    try {
        const { id } = req.params;
        const update = { ...req.body }

        if (typeof update.visibilidade === 'string') {
            const trimmed = update.visibilidade.trim()
            if (trimmed.startsWith('{')) {
                try { update.visibilidade = JSON.parse(trimmed) }
                catch (_) { update.visibilidade = { status: trimmed } }
            } else {
                update.visibilidade = { status: trimmed }
            }
        }
        
        if (update.visibilidade && update.visibilidade.status === 'RESTRICTED') {
            if (req.user && req.user.nivel !== 'administrador') {
                const dbUser = await User.findById(req.user.sub).select('filiacao').lean();
                if (!dbUser || !dbUser.filiacao) {
                    return res.status(400).json({ mensagem: "Não tem filiação associada — não pode marcar recursos como RESTRICTED." });
                }
                update.visibilidade.scope = { filiacao: dbUser.filiacao };
            } else if (req.body.scopeFiliacao) {
                update.visibilidade.scope = { filiacao: req.body.scopeFiliacao };
            } else {
                return res.status(400).json({ mensagem: "Recursos RESTRICTED requerem um scope de filiação associado." });
            }
        } else if (update.visibilidade && update.visibilidade.status !== 'RESTRICTED') {
            update.visibilidade.scope = undefined;
        }

        if (typeof update.hashtags === 'string') {
            update.hashtags = update.hashtags.split(',').map(s => s.trim()).filter(Boolean)
        }

        const files = req.files && req.files.length ? req.files : (req.file ? [req.file] : [])
        if (files.length) {
            const existing = await Resource.findById(id).select('path').lean()
            const projectRoot = path.join(__dirname, '../../')
            const newPaths = files.map(f => path.relative(projectRoot, f.path))
            update.path = [existing && existing.path, ...newPaths].filter(Boolean).join(';')
        }

        delete update.avaliacoes
        delete update.classificacaoMedia
        delete update.numAvaliacoes

        const resource = await Resource.findByIdAndUpdate(id, update, { new: true, timestamps: true }).lean();
        if (!resource) return res.status(404).json({ mensagem: "Não encontrado." });

        return res.status(200).json(resource);
    } catch (error) {
        return res.status(400).json({ error: error.message });
    }
};

exports.deleteResource = async (req, res) => {
    try {
        const recurso = await Resource.findByIdAndUpdate(
            req.params.id,
            { ativo: false },
            { new: true }
        );

        if (!recurso) {
            return res.status(404).json({ mensagem: "Não encontrado." });
        }

        return res.status(200).json({ mensagem: "Recurso desativado com sucesso." });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

function recomputeRatingStats(resource) {
    const lista = resource.avaliacoes || []
    resource.numAvaliacoes = lista.length
    resource.classificacaoMedia = lista.length === 0
        ? 0
        : parseFloat((lista.reduce((s, a) => s + a.valor, 0) / lista.length).toFixed(2))
}

exports.rateResource = async (req, res) => {
    try {
        const valorRaw = req.body && req.body.valor
        const valor = parseFloat(valorRaw)
        if (!Number.isFinite(valor) || valor < 0.5 || valor > 5 || (valor * 2) % 1 !== 0) {
            return res.status(400).json({ erro: 'Valor inválido. Usa um número entre 0.5 e 5 em incrementos de 0.5.' })
        }

        const resource = await Resource.findById(req.params.id)
        if (!resource) return res.status(404).json({ erro: 'Recurso não encontrado.' })
        if (!resource.ativo) return res.status(404).json({ erro: 'Este recurso já não se encontra disponível.' })
        if (resource.estado !== 'aprovado') return res.status(400).json({ erro: 'Apenas recursos aprovados podem ser avaliados.' })
        if (resource.produtor === req.user.sub) return res.status(403).json({ erro: 'Não podes avaliar o teu próprio recurso.' })

        const visFilter = await buildVisibilityFilter(req.user)
        const allowed = await Resource.findOne({ $and: [{ _id: req.params.id }, visFilter] }).select('_id').lean()
        if (!allowed) return res.status(403).json({ erro: 'Sem permissões para avaliar este recurso.' })

        const existente = resource.avaliacoes.find(a => a.user === req.user.sub)
        if (existente) {
            existente.valor = valor
            existente.data = new Date().toISOString().substring(0, 10)
        } else {
            resource.avaliacoes.push({ user: req.user.sub, valor })
        }

        recomputeRatingStats(resource)
        await resource.save()
        return res.status(200).json({
            mensagem: 'Avaliação registada.',
            classificacaoMedia: resource.classificacaoMedia,
            numAvaliacoes: resource.numAvaliacoes,
            minha: valor
        })
    } catch (error) {
        return res.status(400).json({ erro: error.message })
    }
}

exports.removeRating = async (req, res) => {
    try {
        const resource = await Resource.findById(req.params.id)
        if (!resource) return res.status(404).json({ erro: 'Recurso não encontrado.' })

        const tinha = resource.avaliacoes.some(a => a.user === req.user.sub)
        if (!tinha) return res.status(404).json({ erro: 'Ainda não avaliaste este recurso.' })

        resource.avaliacoes = resource.avaliacoes.filter(a => a.user !== req.user.sub)
        recomputeRatingStats(resource)
        await resource.save()
        return res.status(200).json({
            mensagem: 'Avaliação removida.',
            classificacaoMedia: resource.classificacaoMedia,
            numAvaliacoes: resource.numAvaliacoes,
            minha: null
        })
    } catch (error) {
        return res.status(400).json({ erro: error.message })
    }
}

exports.aprovarResource = async (req, res) => {
    try {
        const resource = await Resource.findByIdAndUpdate(req.params.id, { estado: 'aprovado' }, { new: true });
        if (!resource) return res.status(404).json({ mensagem: "Recurso não encontrado." });
        return res.status(200).json({ mensagem: "Recurso aprovado com sucesso.", recurso: resource });
    } catch (error) {
        return res.status(500).json({ erro: error.message });
    }
};

exports.rejeitarResource = async (req, res) => {
    try {
        const resource = await Resource.findByIdAndUpdate(req.params.id, { estado: 'rejeitado' }, { new: true });
        if (!resource) return res.status(404).json({ mensagem: "Recurso não encontrado." });
        return res.status(200).json({ mensagem: "Recurso rejeitado.", recurso: resource });
    } catch (error) {
        return res.status(500).json({ erro: error.message });
    }
};