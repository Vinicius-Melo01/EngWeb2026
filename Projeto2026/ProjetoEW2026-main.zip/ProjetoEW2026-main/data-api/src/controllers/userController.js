const User = require('../models/User')
const Filiacao = require('../models/Filiacao')
const bcrypt = require('bcryptjs')

exports.listUsers = async (req, res) => {
    try {
        const filter = {};

        if (req.query.nome) filter.nome = { $regex: req.query.nome, $options: 'i' };
        if (req.query.email) filter.email = req.query.email;
        if (req.query.nivel) filter.nivel = req.query.nivel; 
        
        if (req.query.filiacao) filter.filiacao = req.query.filiacao;

        const sortField = req.query.sort || 'nome';
        const sortOrder = req.query.order === 'desc' ? -1 : 1;

        const users = await User.find(filter)
            .select('-password') 
            .populate('filiacao')
            .sort({ [sortField]: sortOrder });

        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ message: "Erro na listagem de utilizadores", description: error.message });
    }
};

exports.fetchUser = async (req, res) => {
    try {
        const id = req.params.id;
        
        const user = await User.findById(id).select('-password').populate('filiacao');
        
        if (!user) {
            return res.status(404).json({
                message: "Utilizador não encontrado na base de dados",
                description: `O ID ${id} não existe na base de dados`
            });
        }

        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: "Erro na pesquisa de utilizador", description: error.message });
    }
};

exports.verifyCredentials = async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: "Username e password são obrigatórios." });
        }

        const user = await User.findOne({ _id: username }).populate('filiacao');

        if (!user) {
            return res.status(401).json({ message: "Credenciais inválidas." });
        }

        if (user.ativo === false) {
            return res.status(403).json({ message: "Conta desativada. Contacte o administrador." });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({ message: "Credenciais inválidas." });
        }

        // Atualiza dataUltimoAcesso 
        const now = new Date();
        User.updateOne(
            { _id: user._id },
            { $set: { dataUltimoAcesso: now } },
            { timestamps: false }
        ).catch(err => console.warn('[login] Falha ao atualizar dataUltimoAcesso:', err.message));

        const userResponse = user.toObject();
        userResponse.dataUltimoAcesso = now;
        delete userResponse.password;

        return res.status(200).json(userResponse);

    } catch (error) {
        return res.status(500).json({ 
            message: "Erro ao verificar credenciais", 
            description: error.message 
        });
    }
};

exports.createUser = async (req, res) => {
    try {
        const data = { ...req.body };

        if (!data.filiacao) {
            return res.status(400).json({ mensagem: "A filiação é obrigatória." });
        }
        
        const filiacaoDb = await Filiacao.findById(data.filiacao);
        if (!filiacaoDb || !filiacaoDb.ativa) {
            return res.status(400).json({ mensagem: "A filiação indicada não existe ou não está ativa." });
        }

        if (data.password) {
            data.password = await bcrypt.hash(data.password, 12);
        }
        const newUser = new User(data);
        await newUser.save();
        
        res.status(201).json({ mensagem: "Utilizador criado com sucesso!", id: newUser._id });
    } catch (error) {
        res.status(400).json({ mensagem: "Erro ao registar", erro: error.message });
    }
};

exports.updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const data = { ...req.body };
        
        if (data.filiacao) {
            const filiacaoDb = await Filiacao.findById(data.filiacao);
            if (!filiacaoDb || !filiacaoDb.ativa) {
                return res.status(400).json({ mensagem: "A filiação indicada não existe ou não está ativa." });
            }
        }

        if (data.password) {
            data.password = await bcrypt.hash(data.password, 12);
        }
        
        const user = await User.findByIdAndUpdate(id, data, { new: true }).populate('filiacao').lean();
        
        if (!user) return res.status(404).json({ mensagem: "Não encontrado." });
        
        return res.status(200).json(user);
    } catch (error) {
        return res.status(400).json({ error: error.message });
    }
};

exports.deleteUser = async (req, res) => {
    try {
        const resp = await User.findByIdAndUpdate(req.params.id, { ativo: false }, { new: true });
        if (!resp) return res.status(404).json({ mensagem: "Não encontrado." });
        return res.status(204).send();
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};