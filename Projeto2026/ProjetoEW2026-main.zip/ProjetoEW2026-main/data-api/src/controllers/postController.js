const Post = require('../models/Post')
const Resource = require('../models/Resource')
const Comment = require('../models/Comment')
const { v4: uuidv4 } = require('uuid')
const { buildVisibilityFilter } = require('../utils/visibilityFilter')
const { updateAvgRating } = require('../utils/avgRating')
const { getUsersByIds, getUserById } = require('../utils/userMap')

exports.listPosts = async (req, res) => {
    try {
        let postFilter = {}
        
        if (req.query.produtor) postFilter.produtor = req.query.produtor
        if (req.query.dados) postFilter.dados = req.query.dados
        if (req.query.texto) postFilter.texto = { $regex: req.query.texto, $options: 'i' }

        const sort = req.query.sort || 'produtor'
        const order = req.query.order === 'desc' ? -1 : 1

        const resourceVisibilityFilter = await buildVisibilityFilter(req.user)

        // Recursos visíveis e ativos
        const visibleResources = await Resource.find(resourceVisibilityFilter).select('_id titulo ativo').lean()
        const visibleResourceIds = visibleResources.map(r => r._id)
        const resourceMap = Object.fromEntries(visibleResources.map(r => [r._id, r]))

        // Recursos inativos — incluídos na listagem independentemente de permissões
        const inactiveResources = await Resource.find({ ativo: false }).select('_id titulo ativo').lean()
        const inactiveResourceIds = inactiveResources.map(r => r._id)
        inactiveResources.forEach(r => { resourceMap[r._id] = r })

        const finalFilter = {
            $and: [
                postFilter,
                {
                    $or: [
                        { dados: null },
                        { dados: { $in: visibleResourceIds } },
                        { dados: { $in: inactiveResourceIds } }
                    ]
                }
            ]
        }

        const posts = await Post.find(finalFilter).sort({ [sort]: order }).lean()
        const produtorMap = await getUsersByIds(posts.map(p => p.produtor))

        const result = posts.map(p => ({
            ...p,
            dados: p.dados ?? null,
            produtor: p.produtor ?? null,
            nomeProdutor: produtorMap[p.produtor] ?? null,
            recurso: p.dados && resourceMap[p.dados] ? {
                _id: resourceMap[p.dados]._id,
                titulo: resourceMap[p.dados].titulo,
                ativo: resourceMap[p.dados].ativo
            } : null
        }))

        res.status(200).json(result)
    } catch (error) {
        res.status(500).json({ 
            message: "Erro na listagem de posts", 
            description: error.message 
        })
    }
}

exports.fetchPost = async (req, res) => {
    try {
        const post = await Post.findById(req.params.id).lean()
        if (!post) {
            return res.status(404).json({
                message: "Post não encontrado na base de dados",
                description: `O ID ${req.params.id} não existe na base de dados`
            })
        }

        const produtor = await getUserById(post.produtor)

        if (post.dados) {
            // Buscar o recurso sem filtro de visibilidade para verificar se está ativo
            const recurso = await Resource.findById(post.dados)
                .select('_id titulo ativo')
                .lean()

            // O recurso existe mas está inativo — retorna sem verificar permissões
            if (!recurso.ativo) {
                return res.status(200).json({ ...post, nomeProdutor: produtor?.nome ?? null, recurso })
            }

            const resourceVisibilityFilter = await buildVisibilityFilter(req.user)
            const recursoPermitido = await Resource.findOne({
                $and: [{ _id: post.dados }, resourceVisibilityFilter]
            })
            .select('_id titulo ativo')
            .lean()

            if (!recursoPermitido) {
                return res.status(403).json({ message: "Sem permissão para aceder a este post" })
            }

            return res.status(200).json({ ...post, nomeProdutor: produtor?.nome ?? null, recurso: recursoPermitido })
        }

        res.status(200).json({ ...post, nomeProdutor: produtor?.nome ?? null })
    } catch (error) {
        res.status(500).json({ message: "Erro na pesquisa do post", description: error.message })
    }
}

exports.createPost = async (req, res) => {
    try{
        const { titulo, texto, dados } = req.body || {};

        const newPost = new Post({
            _id: uuidv4(),
            titulo,
            texto,
            dados: dados || null,
            produtor: req.user.sub,
            comentarios: [],
            classificacaoMedia: 0
        });

        await newPost.save();
        res.status(201).json(newPost);
    } catch (error) {
        res.status(400).json({ mensagem: "Erro ao registar", erro: error.message });
    }
}


exports.updatePost = async (req, res) => {
    try {
        const { id } = req.params;

        const post = await Post.findById(id);

        if (!post) 
            return res.status(404).json({ mensagem: 'Post não encontrado' });
        
        const isAdmin = req.user.nivel === 'administrador';
        const isOwner = req.user.nivel === 'produtor' && post.produtor === req.user.sub;

        if (!isAdmin && !isOwner)
            return res.status(403).json({ mensagem: 'Sem permissão para editar este post' });

        const { titulo, texto, dados } = req.body || {};
        const update = {};
        if (titulo !== undefined) update.titulo = titulo;
        if (texto !== undefined) update.texto = texto;
        if (dados !== undefined) update.dados = dados || null;

        const updatedPost = await Post.findByIdAndUpdate(id, update, { new: true }).lean();
        
        return res.status(200).json(updatedPost);
    } catch (error) {
        return res.status(400).json({ error: error.message });
    }
};

exports.deletePost = async (req, res) => {
    try {

        const { id } = req.params;

        const post = await Post.findById(id);

        if (!post) 
            return res.status(404).json({ mensagem: 'Post não encontrado' });
        
        const isAdmin = req.user.nivel === 'administrador';
        const isOwner = req.user.nivel === 'produtor' && post.produtor === req.user.sub;

        if (!isAdmin && !isOwner) 
            return res.status(403).json({ mensagem: 'Sem permissão para eliminar este post' });

        const resp = await Post.findByIdAndDelete(id);
        return res.status(204).send();
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

// Criar um novo comentário e atualizar o post
exports.addCommentToPost = async (req, res) => {
    try {
        const { postId } = req.params;
        
        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({ 
                message: "Post não encontrado",
                description: `O ID ${postId} não existe`
            });
        }
        
        const { texto, avaliacao } = req.body || {};
        const newComment = new Comment({
            _id: uuidv4(),
            criador: req.user.sub,
            post: postId,
            texto,
            avaliacao
        });
        await newComment.save();
        
        if (!post.comentarios) post.comentarios = [];
        post.comentarios.push(newComment._id);
        
        await updateAvgRating(post, Comment);
        
        res.status(201).json({ 
            comment: newComment, 
            post: post 
        });
    } catch (error) {
        res.status(400).json({ 
            mensagem: "Erro ao adicionar comentário ao post", 
            erro: error.message 
        });
    }
};

// Editar um comentário e atualizar a classificação média do post
exports.updateCommentInPost = async (req, res) => {
    try {
        const { postId, commentId } = req.params;
        
        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({ 
                message: "Post não encontrado",
                description: `O ID ${postId} não existe`
            });
        }
        
        // Importante para verificar permissões
        const existingComment = await Comment.findById(commentId);
        if (!existingComment) {
            return res.status(404).json({ 
                message: "Comentário não encontrado",
                description: `O ID ${commentId} não existe`
            });
        }

        const isAdmin = req.user.nivel === 'administrador';
        const isOwner = req.user.sub === existingComment.criador;

        if (!isAdmin && !isOwner)
            return res.status(403).json({ mensagem: 'Sem permissão para editar este comentário' });

        const { texto, avaliacao } = req.body || {};
        const update = {};
        if (texto !== undefined) update.texto = texto;
        if (avaliacao !== undefined) update.avaliacao = avaliacao;

        const comment = await Comment.findByIdAndUpdate(commentId, update, { new: true });
        if (!comment) {
            return res.status(404).json({ 
                message: "Comentário não encontrado",
                description: `O ID ${commentId} não existe`
            });
        }
        
        await updateAvgRating(post, Comment);
        
        res.status(200).json({ 
            comment: comment, 
            post: post 
        });
    } catch (error) {
        res.status(400).json({ 
            error: error.message 
        });
    }
};

// Remover um comentário do post e atualizar a classificação média
exports.removeCommentFromPost = async (req, res) => {
    try {
        const { postId, commentId } = req.params;
        
        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({ 
                message: "Post não encontrado",
                description: `O ID ${postId} não existe`
            });
        }
        
        // Importante para verificar permissões
        const existingComment = await Comment.findById(commentId);
        if (!existingComment) {
            return res.status(404).json({ 
                message: "Comentário não encontrado",
                description: `O ID ${commentId} não existe`
            });
        }
        
        const isAdmin = req.user.nivel === 'administrador';
        const isProducerAndOwnerOfPost = (req.user.nivel === 'produtor' && post.produtor === req.user.sub);
        const isConsumerAndOwnerOfComment = req.user.sub === existingComment.criador;
        
        const temPermissao = isAdmin || isProducerAndOwnerOfPost || isConsumerAndOwnerOfComment;

        if (!temPermissao)
            return res.status(403).json({ mensagem: 'Sem permissão para eliminar este post' });

        const deletedComment = await Comment.findByIdAndDelete(commentId);
        
        post.comentarios = post.comentarios.filter(id => id !== commentId);
        
        await updateAvgRating(post, Comment);
        
        res.status(200).json({ 
            message: "Comentário removido com sucesso",
            post: post 
        });
    } catch (error) {
        res.status(500).json({ 
            error: error.message 
        });
    }
};