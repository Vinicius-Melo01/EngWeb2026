const Filiacao = require('../models/Filiacao')

exports.listFiliacoes = async (req, res) => {
    try {
        const { nome, tipo, instituicao, curso, ativa } = req.query

        const sort = req.query.sort || 'nome'
        const order = req.query.order === 'desc' ? -1 : 1 

        const query = {}

        if (nome) query.nome = { $regex: nome, $options: 'i' }
        if (tipo) query.tipo = tipo 
        if (instituicao) query.instituicao = { $regex: instituicao, $options: 'i' }
        if (curso) query.curso = { $regex: curso, $options: 'i' }
        
        if (ativa !== undefined) {
            query.ativa = ativa === 'true'
        }

        const filiacoes = await Filiacao.find(query).sort({ [sort]: order })

        res.status(200).json(filiacoes)

    } catch (e) {
        res.status(500).json({ error: e.message })
    }
}

exports.fetchFiliacao = async (req, res) => {
    try {
        const fil = await Filiacao.findById(req.params.id);
        if (!fil) {
            return res.status(404).json({
                message: "Filiação não encontrada na base de dados",
                description: `O ID ${req.params.id} não existe na base de dados`
            })
        }
        res.status(200).json(fil);
    } catch (error) {
        res.status(500).json({ message: "Erro na pesquisa da filiação", description: error.message });
    }
}

exports.createFiliacao = async (req, res) => {
    try {
        if (!req.body || Object.keys(req.body).length === 0) {
            return res.status(400).json({ mensagem: "Corpo do pedido em falta ou vazio." });
        }

        const newFiliacao = new Filiacao(req.body);

        await newFiliacao.save();
        res.status(201).json(newFiliacao);
    } catch (error) {
        res.status(400).json({ mensagem: "Erro ao registar Filiação", erro: error.message });
    }
}

exports.editFiliacao = async (req, res) => {
    try {
        const { id } = req.params;

        if (!req.body || Object.keys(req.body).length === 0) {
            return res.status(400).json({ mensagem: "Corpo do pedido em falta ou vazio." });
        }

        const filiacaoAtualizada = await Filiacao.findByIdAndUpdate(
            id, 
            req.body, 
            { new: true, runValidators: true }
        );

        if (!filiacaoAtualizada) {
            return res.status(404).json({ mensagem: "Filiação não encontrada." });
        }

        res.status(200).json(filiacaoAtualizada);

    } catch (error) {
        res.status(400).json({ mensagem: "Erro ao atualizar filiação", erro: error.message });
    }
}

exports.desativarFiliacao = async (req, res) => {
    try {
        const { id } = req.params;

        const fil = await Filiacao.findByIdAndUpdate(id, { ativa: false }, { new: true });

        if (!fil) {
            return res.status(404).json({ mensagem: 'Filiação não encontrada' });
        }

        return res.status(204).send();
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};