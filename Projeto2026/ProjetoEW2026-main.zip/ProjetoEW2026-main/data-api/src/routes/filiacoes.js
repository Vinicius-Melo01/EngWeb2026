const express = require('express')
const router = express.Router()
const filiacaoController = require('../controllers/filiacaoController')
const auth = require('../middleware/auth')

// PÚBLICAS (Necessário para a Fase 3 - Dropdowns de Registo)
router.get('/', filiacaoController.listFiliacoes)
router.get('/:id', filiacaoController.fetchFiliacao)

// PRIVADAS (Apenas Administrador)
router.post('/', auth.requireAuth, auth.requireLevel('administrador'), filiacaoController.createFiliacao)
router.put('/:id', auth.requireAuth, auth.requireLevel('administrador'), filiacaoController.editFiliacao)
router.delete('/:id', auth.requireAuth, auth.requireLevel('administrador'), filiacaoController.desativarFiliacao)

module.exports = router