const express = require('express')
const router = express.Router();
const postController = require('../controllers/postController')
const auth = require('../middleware/auth')

router.get('/', postController.listPosts)

router.post('/register', auth.attachUser, auth.requireAuth, auth.requireLevel('produtor', 'administrador'), postController.createPost)

router.get('/:id', auth.attachUser, postController.fetchPost)

router.patch('/:id', auth.attachUser, auth.requireAuth, postController.updatePost)

router.delete('/:id', auth.attachUser, auth.requireAuth, postController.deletePost)

// Criar comentário para um post
router.post('/:postId/comments', auth.attachUser, auth.requireAuth, postController.addCommentToPost)

// Editar comentário de um post
router.patch('/:postId/comments/:commentId', auth.attachUser, auth.requireAuth, postController.updateCommentInPost)

// Remover comentário de um post
router.delete('/:postId/comments/:commentId', auth.attachUser, auth.requireAuth, postController.removeCommentFromPost)

module.exports = router;