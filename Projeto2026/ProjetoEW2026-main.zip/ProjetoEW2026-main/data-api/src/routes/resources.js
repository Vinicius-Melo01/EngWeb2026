const express = require('express')
const router = express.Router()
const resourceController = require('../controllers/resourceController')
const { exportDIP } = require('../controllers/exportController')
const { uploadResource } = require('../middleware/upload')
const { attachUser, requireAuth, requireLevel } = require('../middleware/auth')

router.get('/', resourceController.listResource)
router.get('/:id', attachUser, requireAuth, resourceController.fetchResource)

// Submeter recursos requer login (produtor ou administrador)
router.post('/', requireLevel('produtor', 'administrador'), uploadResource.array('files', 10), resourceController.createResource)
router.post('/register', requireLevel('produtor', 'administrador'), uploadResource.array('files', 10), resourceController.createResource)

router.put('/:id', requireAuth, uploadResource.array('files', 10), resourceController.updateResource)
router.patch('/:id', requireAuth, uploadResource.array('files', 10), resourceController.updateResource)
router.delete('/:id', requireAuth, resourceController.deleteResource)

// Aprovar/rejeitar é exclusivo de administradores
router.patch('/:id/aprovar', requireLevel('administrador'), resourceController.aprovarResource)
router.patch('/:id/rejeitar', requireLevel('administrador'), resourceController.rejeitarResource)

// Avaliar (estrelas) — apenas consumidores e administradores; cada user só tem 1 avaliação por recurso
router.post('/:id/avaliar', requireLevel('consumidor', 'administrador'), resourceController.rateResource)
router.delete('/:id/avaliar', requireLevel('consumidor', 'administrador'), resourceController.removeRating)

// GET /api/resources/:id/export — Gera DIP (ZIP BagIt) - filtragem aplicada no controller
router.get('/:id/export', exportDIP)

module.exports = router