const express = require('express')
const router = express.Router()
const { uploadSIP } = require('../middleware/upload')
const { validateSIP } = require('../middleware/validate')
const { ingestSIP } = require('../controllers/ingestController')

// POST /api/ingest — Upload de SIP (ZIP BagIt) + validação + ingestão
// Wrapper para capturar erros do Multer e devolver relatório JSON
router.post('/', (req, res, next) => {
    uploadSIP.single('file')(req, res, (err) => {
        if (err) {
            return res.status(400).json({
                erro: 'Falha no upload do SIP',
                relatorio: {
                    valido: false,
                    motivo: err.message,
                    timestamp: new Date().toISOString()
                }
            })
        }
        next()
    })
}, validateSIP, ingestSIP)

module.exports = router
