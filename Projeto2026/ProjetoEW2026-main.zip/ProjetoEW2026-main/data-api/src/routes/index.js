const express = require('express')
const userRouter = require('./users')
const resourceRouter = require('./resources')
const postRouter = require('./posts')
const commentRouter = require('./comments')
const exportRouter = require('./export')
const ingestRouter = require('./ingest')
const filiacaoRouter = require('./filiacoes')
const router = express.Router()

router.use('/api/users' ,userRouter)
router.use('/api/resources', resourceRouter)
router.use('/api/posts', postRouter)
router.use('/api/comments', commentRouter)
router.use('/api/export', exportRouter)
router.use('/api/ingest', ingestRouter)
router.use('/api/filiacoes', filiacaoRouter)

module.exports = router;