const express = require('express')
const router = express.Router()
const userController = require('../controllers/userController')
const auth = require('../middleware/auth')

router.get('/',auth.requireAuth, auth.attachUser, auth.requireLevel('administrador'),userController.listUsers)

router.post('/register', userController.createUser)

router.post('/login', userController.verifyCredentials);

router.get('/:id',auth.requireAuth, auth.attachUser, auth.requireLevel('administrador'), userController.fetchUser)

router.patch('/:id',auth.requireAuth, auth.attachUser, auth.requireLevel('administrador'), userController.updateUser)

router.delete('/:id',auth.requireAuth, auth.attachUser, auth.requireLevel('administrador'), userController.deleteUser)

module.exports = router