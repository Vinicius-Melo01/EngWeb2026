const express = require('express')
const router = express.Router();
const commentController = require('../controllers/commentController')

router.get('/', commentController.listComments)

router.post('/register', commentController.createComment)

router.get('/:id', commentController.fetchComment)

router.patch('/:id', commentController.updateComment)

router.delete('/:id', commentController.deleteComment)

module.exports = router;