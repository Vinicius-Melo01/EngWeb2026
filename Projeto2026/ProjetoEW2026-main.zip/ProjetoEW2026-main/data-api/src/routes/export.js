const express = require('express')
const router = express.Router()
const multer = require('multer')
const exportController = require('../controllers/exportController')
const { requireLevel } = require('../middleware/auth')

// Memory storage: o controller decide se trata como ZIP ou JSON
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 1024 * 1024 * 1024 } // 1GB
})

// Operações de import/export estão restritas a administradores
router.get('/', requireLevel('administrador'), exportController.exportAll)
router.post('/', requireLevel('administrador'), upload.single('ficheiro'), exportController.importAll)

module.exports = router
