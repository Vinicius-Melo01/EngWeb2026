const User = require('../models/user');

// Devolve a lista de todos os utilizadores (com suporte a filtros)
module.exports.listar = (filtro = {}) => {
    return User
        .find(filtro)
        .sort({ nome: 1 })
        .exec();
};

// Devolve um utilizador pelo seu ID
module.exports.consultar = (id) => {
    return User
        .findOne({ _id: id })
        .exec();
};

// Devolve um utilizador pelo username (útil para verificação rápida)
module.exports.consultarUsername = (un) => {
    return User
        .findOne({ username: un })
        .exec();
};

// Insere um novo utilizador
module.exports.inserir = (u) => {
    const novo = new User(u);
    return novo.save();
};

// Remove um utilizador
module.exports.remover = (id) => {
    return User
        .deleteOne({ _id: id })
        .exec();
};

// Atualiza os dados de um utilizador
module.exports.alterar = (id, u) => {
    return User
        .updateOne({ _id: id }, u)
        .exec();
};