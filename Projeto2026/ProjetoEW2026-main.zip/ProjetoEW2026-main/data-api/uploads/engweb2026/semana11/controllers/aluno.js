const Aluno = require('../models/aluno');

module.exports.list = () => {
    return Aluno.find().sort({ nome: 1 }).exec();
};

module.exports.findById = id => {
    return Aluno.findOne({ _id: id }).exec();
};

module.exports.insert = a => {
    // Se o dataset vier com idAluno, mapeamos para _id
    if (a.idAluno && !a._id) a._id = a.idAluno;
    const novo = new Aluno(a);
    return novo.save();
};

module.exports.update = (id, a) => {
    // Limpeza rápida para evitar que strings vazias quebrem o tipo Number
    if (a.exames) {
        if (a.exames.normal === "") delete a.exames.normal;
        if (a.exames.recurso === "") delete a.exames.recurso;
        if (a.exames.especial === "") delete a.exames.especial;
    }
    return Aluno.updateOne({ _id: id }, a).exec();
};

module.exports.remove = id => {
    return Aluno.deleteOne({ _id: id }).exec();
};

// Exemplo de agregação para calcular nota final (Opcional)
module.exports.stats = () => {
    return Aluno.aggregate([
        // Podes adicionar aqui cálculos de médias se desejares
    ]).exec();
};