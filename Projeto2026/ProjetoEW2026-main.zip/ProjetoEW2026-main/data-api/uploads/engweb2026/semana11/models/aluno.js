const mongoose = require('mongoose');

const alunoSchema = new mongoose.Schema({
    _id: { type: String, required: true }, // Mapeia idAluno
    nome: { type: String, required: true },
    curso: { type: String, required: true },
    tpc: [{
        tp: String,
        nota: Number
    }],
    projeto: Number,
    exames: {
        normal: { type: Number, default: 0 },
        recurso: { type: Number, default: 0 },
        especial: { type: Number, default: 0 }
    }
}, { versionKey: false });

module.exports = mongoose.model('aluno', alunoSchema);