const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { 
        type: String, 
        required: true, 
        unique: true 
    },
    password: { 
        type: String, 
        required: true 
    },
    nome: { 
        type: String, 
        required: true 
    },
    role: { 
        type: String, 
        enum: ['admin', 'user', 'aluno'], // Ajusta conforme as tuas necessidades
        default: 'aluno'
    }
}, { versionKey: false });

module.exports = mongoose.model('user', userSchema, 'users');