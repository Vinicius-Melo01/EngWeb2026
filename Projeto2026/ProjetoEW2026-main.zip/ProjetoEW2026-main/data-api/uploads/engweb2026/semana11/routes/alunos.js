const express = require('express');
const router = express.Router();
const Aluno = require('../controllers/aluno');

router.get('/', (req, res) => {
    Aluno.list()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro.message }));
});

router.get('/:id', (req, res) => {
    Aluno.findById(req.params.id)
        .then(dados => {
            if (dados) res.json(dados);
            else res.status(404).json({ mensagem: "Aluno não encontrado" });
        })
        .catch(erro => res.status(500).json({ erro: erro.message }));
});

router.post('/', (req, res) => {
    Aluno.insert(req.body)
        .then(dados => res.status(201).json(dados))
        .catch(erro => res.status(500).json({ erro: erro.message }));
});

router.put('/:id', (req, res) => {
    Aluno.update(req.params.id, req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro.message }));
});

router.delete('/:id', (req, res) => {
    Aluno.remove(req.params.id)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro.message }));
});

module.exports = router;