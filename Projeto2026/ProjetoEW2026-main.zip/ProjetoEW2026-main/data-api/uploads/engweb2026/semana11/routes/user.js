const express = require('express');
const router = express.Router();
const UserControl = require('../controllers/user');

// GET /users - Lista utilizadores (suporta filtros por query string, ex: ?username=jcr)
router.get('/', (req, res) => {
    UserControl.listar(req.query)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro, mensagem: "Erro na listagem de utilizadores." }));
});

// GET /users/:id - Consulta um utilizador por ID
router.get('/:id', (req, res) => {
    UserControl.consultar(req.params.id)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro, mensagem: "Erro a consultar utilizador." }));
});

// POST /users - Cria um novo utilizador
router.post('/', (req, res) => {
    UserControl.inserir(req.body)
        .then(dados => res.status(201).json(dados))
        .catch(erro => res.status(500).json({ erro: erro, mensagem: "Erro no registo do utilizador." }));
});

// PUT /users/:id - Atualiza um utilizador
router.put('/:id', (req, res) => {
    UserControl.alterar(req.params.id, req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro, mensagem: "Erro na alteração do utilizador." }));
});

// DELETE /users/:id - Remove um utilizador
router.delete('/:id', (req, res) => {
    UserControl.remover(req.params.id)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).json({ erro: erro, mensagem: "Erro na remoção do utilizador." }));
});

module.exports = router;