const axios = require('axios')
const jwt = require('jsonwebtoken')

const COOKIE_NAME = process.env.AUTH_COOKIE || 'auth_token'
const JWT_SECRET = process.env.JWT_SECRET
const DATA_API_URL = process.env.DATA_API_URL
const WEB_URL = process.env.WEB_URL

function validateAccess(req, res, next) {
    const token = req.cookies[COOKIE_NAME]
    if (!token) return res.redirect('/login')

    jwt.verify(token, JWT_SECRET, (err, payload) => {
        if (err) return res.redirect('/login')
        req.user = payload
        next()
    })
}

async function checkCredentials(req, res, next) {
    try {
        const { username, password } = req.body

        if (!username || !password) {
            return res.render('login', {
                title: 'Login',
                erro: 'Username e password sao obrigatorios.'
            })
        }

        const resp = await axios.post(`${DATA_API_URL}/api/users/login`, {
            username,
            password
        })

        req.user = resp.data
        next()

    } catch (error) {
        if (error.response && error.response.status === 401) {
            return res.render('login', { title: 'Login', erro: 'Credenciais invalidas.' })
        }
        if (error.response && error.response.status === 403) {
            return res.render('login', {
                title: 'Login',
                erro: error.response.data.message || 'Conta desativada.'
            })
        }

        console.error('Erro ao contactar API de dados:', error.message)
        return res.render('login', {
            title: 'Login',
            erro: 'Servico temporariamente indisponivel.'
        })
    }
}

function generateToken(req, res, next) {
    const user = req.user

    const token = jwt.sign(
        {
            sub: user._id,
            email: user.email,
            nome: user.nome,
            nivel: user.nivel,
            filiacao: user.filiacao
        },
        JWT_SECRET,
        { expiresIn: '3h' }
    )

    res.cookie(COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        path: '/',
        maxAge: 3600000 * 3
    })

    req.token = token
    next()
}

function redirectAfterLogin(req, res) {
    return res.redirect(WEB_URL || '/')
}

async function registerUser(req, res) {
    try {
        const { username, nome, email, password, password2, filiacao } = req.body

        if (!username || !nome || !email || !password) {
            return await renderRegister(res, 'Username, Nome, email e password sao obrigatorios.', req.body)
        }

        if (password !== password2) {
            return await renderRegister(res, 'As passwords nao coincidem.', req.body)
        }

        if (!filiacao) {
            return await renderRegister(res, 'É obrigatório selecionar uma filiação.', req.body)
        }

        const newUser = {
            _id: username,
            nome,
            email,
            password,
            nivel: 'consumidor',
            filiacao
        }

        await axios.post(`${DATA_API_URL}/api/users/register`, newUser)

        // Fazer login automatico apos registo (username = _id)
        const loginResp = await axios.post(`${DATA_API_URL}/api/users/login`, {
            username: newUser._id,
            password
        })

        req.user = loginResp.data
        return 'registered'

    } catch (error) {
        const mensagem = error.response
            ? (error.response.data.erro || error.response.data.mensagem || 'Erro no registo.')
            : 'Servico temporariamente indisponivel.'

        return await renderRegister(res, mensagem, req.body)
    }
}

// Helper: re-renderiza o form de registo carregando sempre as filiações ativas
async function renderRegister(res, erro, form) {
    let filiacoes = []
    try {
        const resp = await axios.get(`${DATA_API_URL}/api/filiacoes?ativa=true`)
        filiacoes = resp.data
    } catch (_) { /* deixa vazio */ }
    return res.render('register', { title: 'Registo', erro, form, filiacoes })
}

function clearCookie(req, res) {
    res.clearCookie(COOKIE_NAME, { path: '/' })
    res.redirect('/login')
}

module.exports = { validateAccess, generateToken, checkCredentials, clearCookie, registerUser, redirectAfterLogin }
