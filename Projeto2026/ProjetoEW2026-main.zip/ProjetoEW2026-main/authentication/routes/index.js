var express = require('express');
var router = express.Router();
var axios = require('axios');
const DATA_API_URL = process.env.DATA_API_URL || 'http://localhost:3000';
var { checkCredentials, generateToken, redirectAfterLogin, registerUser, clearCookie } = require('../middleware/authentication');

router.get('/', function(req, res) {
    res.redirect('/login');
});

router.get('/login', function(req, res) {
    res.render('login', { title: 'Login' });
});

router.post('/login', checkCredentials, generateToken, redirectAfterLogin);

router.get('/register', async function(req, res) {
    try {
        const response = await axios.get(`${DATA_API_URL}/api/filiacoes?ativa=true`);
        res.render('register', { title: 'Registo', filiacoes: response.data });
    } catch (error) {
        console.error("Erro ao buscar filiações para o registo:", error.message);
        res.render('register', { title: 'Registo', filiacoes: [] }); 
    }
});
router.post('/register', async function(req, res) {
    var result = await registerUser(req, res);
    if (result === 'registered') {
        generateToken(req, res, function() {
            redirectAfterLogin(req, res);
        });
    }
});

// --- Logout ---
router.get('/logout', clearCookie);

module.exports = router;
