# Relatório do Trabalho Prático de Engenharia Web
Tema: Plataforma de Gestão e Disponibilização de Recursos Educativos.

Licenciatura de Engenharia Informática, Universidade do Minho.

Maio de 2026

## Alunos: 
- Diogo José Fernandes Esteves, A104004
- Luís Filipe Araújo Ferreira, A98286
- Vinícius Gomes Roriz de Melo, A101926

## Introdução

Este relatório descreve o desenvolvimento de uma plataforma web para a gestão e disponibilização de recursos educativos, realizado no âmbito da unidade curricular de Engenharia Web. O objetivo principal foi construir um sistema que permita submeter, classificar e partilhar recursos de vários tipos, como programas, datasets, textos, entre outros, com controlo de acesso baseado em três níveis de utilizador: **administrador**, **produtor** e **consumidor**.

A plataforma foi desenvolvida com uma arquitetura de microserviços, onde cada componente tem responsabilidades bem delimitadas e comunica com os restantes através de HTTP. A orquestração de todos os serviços é feita com **Docker Compose**, o que permite arrancar toda a infraestrutura com um único comando (`docker compose up`), garantindo reprodutibilidade e isolamento entre componentes.

A solução é composta por quatro serviços principais:
- **`mongodb`**: base de dados documental utilizando o MongoDB, inicializada automaticamente com um dataset de exemplo;
- **`data-api`**: API REST que centraliza toda a lógica de negócio e o acesso aos dados da base de dados;
- **`web`**: servidor de interface que consome a `data-api` e serve as páginas ao utilizador final com templates em Pug;
- **`authentication`**: serviço dedicado ao login, registo e emissão de tokens JWT.

Entre as funcionalidades implementadas destacam-se: o workflow de submissão e aprovação de recursos, um sistema de posts e comentários com classificação por estrelas, controlo de visibilidade por filiação institucional (pública, privada ou restrita), ingestão de pacotes SIP no formato BagIt com validação de checksums, e exportação de recursos como pacotes DIP. O sistema suporta ainda a exportação e importação global da plataforma num pacote ZIP que inclui não só a totalidade dos dados em JSON como também a árvore de ficheiros físicos carregados, disponível aos administradores. Cada serviço Express expõe ainda a sua própria documentação **OpenAPI 3.0** em `/api-docs`, gerada com `swagger-ui-express`.

### Arquitetura e fluxo de pedidos

Os quatro serviços comunicam exclusivamente através de HTTP, na rede interna criada pelo Docker Compose. O fluxo típico de um pedido autenticado é o seguinte:

1. O utilizador acede ao serviço `authentication` para efetuar login. Após validação das credenciais junto da `data-api`, é-lhe atribuído um *cookie* `httpOnly` com um JWT.
2. O *browser* passa a fazer pedidos ao serviço `web`, que automaticamente reencaminha o JWT recebido para a `data-api` no cabeçalho `Authorization`.
3. A `data-api` valida o JWT, aplica as regras de visibilidade e nível de acesso, lê/escreve no MongoDB e devolve os dados.
4. O serviço `web` recebe os dados, renderiza a vista em Pug e devolve o HTML ao *browser*.


## Base de dados (mongodb)

A base de dados utilizada é o **MongoDB**, correndo num contentor Docker construído a partir de uma imagem personalizada que executa automaticamente a importação dos dados iniciais através do script `init.sh`. Este script usa `mongoimport` para popular cinco coleções na base de dados `plataformaEW26` a partir do momento em que o contentor arranca pela primeira vez. Os dados são persistidos num volume Docker (`mongo-data`).

A base de dados é composta por cinco coleções:

- **`utilizadores`**: Utilizadores da plataforma, com nome, email, password cifrada com *bcrypt*, nível de acesso (administrador, produtor ou consumidor), filiação   institucional e um campo `ativo` para suporte a soft-delete;

- **`recursos`**: Recursos educativos, com metainformação como título, tipo, caminho para o ficheiro, hashtags, estado de aprovação (pendente, aprovado ou rejeitado) e visibilidade (PUBLIC, PRIVATE ou RESTRICTED), podendo esta última ser restringida a uma filiação institucional específica;

- **`posts`**: Publicações de utilizadores sobre recursos, com referência ao recurso associado, lista de comentários e classificação média calculada automaticamente;

- **`comentarios`**: Comentários a posts, com avaliação numérica entre 0,5 e 5 estrelas que alimenta o sistema de ranking;

- **`filiacao`**: filiações institucionais disponíveis (departamentos, cursos, grupos de investigação), com campo `ativa` para desativação sem eliminação de dados históricos.

Além disso, são definidos nos modelos do Mongoose índices sobre os campos mais consultados, por exemplo, email, nivel nos  utilizadores, estado, hashtags nos recursos, etc., de forma a otimizar as queries mais frequentes da aplicação.

A maioria dos modelos utiliza ainda a opção `timestamps` do Mongoose, que mantém automaticamente os campos `dataRegisto` (criação) e `dataUltimaAlteracao`/`dataUltimoAcesso` (última escrita) em qualquer operação, evitando inconsistências entre código e base de dados.

---

## Serviço de Dados (data-api)

A `data-api` é o serviço central da plataforma. Trata-se de uma API REST construída com **Express.js** e **Mongoose** onde contém toda a lógica de negócio e onde é feita a comunicação com a base de dados. Os restantes serviços (interface e authentication) interagem com a plataforma exclusivamente através dos seus endpoints.

O código da `data-api` está organizado segundo um padrão simplificado de **MVC** (Model-View-Controller). As responsabilidades estão divididas em três camadas: os **modelos** (`models/`) definem os esquemas Mongoose de cada coleção e as suas validações; os **controllers** (`controllers/`) contêm a lógica de negócio de cada operação; e as **rotas** (`routes/`) mapeiam os endpoints HTTP para os controllers correspondentes, aplicando os middlewares de autenticação necessários. Esta separação facilita a manutenção e a extensão do código, tornando cada camada independente e testável isoladamente.

### Autenticação e Controlo de Acesso

A autenticação é feita com **JWT** (*JSON Web Tokens*). O middleware `attachUser` tenta extrair e verificar o token do cabeçalho em cada pedido, populando `req.user` com as claims do utilizador (identificador, email, nome, nível e filiação). Os middlewares `requireAuth` e `requireLevel` protegem as rotas que requerem autenticação ou um nível de acesso específico.

### Recursos Educativos

Os recursos são os dados principais da plataforma. Ao serem submetidos por um produtor ou administrador ficam no estado `pendente` até serem aprovados ou rejeitados por um administrador. O acesso a cada recurso é filtrado dinamicamente pela função `buildVisibilityFilter`, que constrói um filtro MongoDB consoante o utilizador autenticado: administradores vêem tudo; produtores vêem os seus próprios recursos e os aprovados públicos ou restritos à sua filiação; consumidores e utilizadores não autenticados apenas acedem aos recursos públicos aprovados.

A submissão de recursos suporta o **carregamento simultâneo de múltiplos ficheiros**, geridos no servidor via `multer` com armazenamento em disco e organizados por tipo dentro da pasta `uploads/`. Os caminhos relativos resultantes são guardados no campo `path` do recurso, separados por `;`, o que permite que um único recurso agregue, por exemplo, vários ficheiros de um mesmo dataset.

No caso de um recurso ser marcado como `RESTRICTED`, é necessário associar-lhe uma filiação institucional. A política adoptada é a seguinte: **um produtor é forçado a usar a sua própria filiação** (validado no servidor), enquanto um **administrador pode escolher livremente qualquer filiação ativa** a partir de um *dropdown* pré-carregado. Na visualização (`buildVisibilityFilter`), um utilizador autenticado só vê recursos `RESTRICTED` cujo `scope.filiacao` coincida com a sua filiação.

### Workflow de Aprovação

A moderação de recursos é feita exclusivamente por administradores. No detalhe de qualquer recurso pendente, são apresentados botões de **Aprovar** e **Rejeitar**, que invocam respectivamente os endpoints `PATCH /api/resources/:id/aprovar` e `PATCH /api/resources/:id/rejeitar`. A interface destes botões fica oculta para utilizadores sem privilégios e a `data-api` valida novamente o nível de acesso antes de mudar o estado.

### Posts e Comentários

Os produtores e administradores podem criar posts sobre recursos, permitindo partilhar observações, notas técnicas ou opiniões acerca de um recurso específico. Cada post referencia o recurso através do campo `dados` e agrega uma lista de IDs de comentários e uma `classificacaoMedia`, calculada automaticamente a partir das avaliações dos comentários recebidos.

Os comentários são criados por qualquer utilizador autenticado e incluem, além do texto, uma avaliação numérica entre 0,5 e 5 estrelas em incrementos de 0,5. Sempre que um comentário é adicionado, editado ou removido, a classificação média do post é recalculada no momento, fazendo a média de todas as avaliações existentes. Este valor serve como sistema de ranking dos recursos.

### Ingestão de SIPs e Exportação de DIPs

A plataforma suporta o formato **BagIt** para a submissão e a exportação de recursos. Na ingestão (`POST /api/ingest`), o servidor recebe um ficheiro ZIP, valida a sua estrutura BagIt através do middleware `validateSIP` e, se válido, extrai os ficheiros para o sistema de ficheiros e cria o registo do recurso com o estado `pendente`. Na exportação (`GET /api/resources/:id/export`), é gerado um pacote DIP: um ZIP com os ficheiros do recurso, os seus metadados em JSON e um manifesto `manifest-sha256.txt`, garantindo
a integridade do pacote.

### Filiações Institucionais

As filiações são geridas como uma entidade própria, em vez de campos livres no perfil de cada utilizador. Cada filiação tem um identificador, nome, tipo (`ESTUDANTE`, `DOCENTE` ou `INVESTIGADOR`), instituição, curso/departamento e um campo `ativa` que permite ocultá-las sem perder dados históricos. Apenas administradores podem criar, editar ou desativar filiações; os restantes utilizadores apenas as **selecionam** (em listas pré-filtradas) no momento do registo ou na atribuição da visibilidade restrita de um recurso.

No formulário de registo, os campos de filiação aparecem em três *selects* encadeados — Tipo → Instituição → Curso/Departamento — permitindo navegar pelas filiações ativas. Esta abordagem garante consistência e simplifica a aplicação das regras de visibilidade.

### Exportação e Importação Globais

A `data-api` expõe ainda dois endpoints `GET /api/export` e `POST /api/export`, restritos a administradores, que permitem fazer um *backup* completo da plataforma. O export devolve um ficheiro ZIP contendo um `data.json` com **todas as coleções** (utilizadores, recursos, posts, comentários e filiações) e a árvore completa da pasta `uploads/` com os ficheiros físicos. Para o efeito, é usada a biblioteca `archiver` em modo *streaming*, evitando carregar grandes volumes em memória.

O import aceita o mesmo formato, detetando o tipo do ficheiro. Os dados são reinseridos com `insertMany({ ordered: false })`, ignorando duplicados, e os ficheiros físicos são reescritos no `uploads/` com proteção contra ataques de *path-traversal*. Esta funcionalidade simplifica significativamente operações de backup e migração.

---

## Serviço de Interface (web)

O serviço `web` é o ponto de entrada da plataforma para o utilizador final. É um servidor **Express.js** que serve páginas HTML geradas com templates **Pug**. Este serviço não acede diretamente à base de dados e funciona como o intermediário entre o browser e a `data-api`, reencaminhando os pedidos e construindo as vistas com os dados recebidos.

### Comunicação com a `data-api`

Todas as operações sobre os dados são delegadas à `data-api` via HTTP, usando Axios para pedidos simples e a Fetch API para pedidos com ficheiros. O token JWT do utilizador autenticado, armazenado num cookie `httpOnly`, é extraído e propagado automaticamente em cada pedido à `data-api` através do cabeçalho `Authorization: Bearer <token>`, garantindo
que as regras de controlo de acesso são aplicadas corretamente na camada de dados.

### Estrutura de Rotas

As rotas estão organizadas por entidade em ficheiros separados. As rotas públicas (como a homepage) estão acessíveis sem autenticação. Todas as rotas sob o prefixo `/rep` requerem login, verificado pelo middleware `requireAuth`. Algumas rotas têm restrições adicionais de nível: a gestão de utilizadores e filiações está reservada a administradores, e a criação de posts e submissão de recursos está limitada a produtores e administradores.

### Funcionalidades da Interface

A homepage agrega, em paralelo, os posts mais recentes, os recursos mais recentes e os recursos mais bem classificados, apresentando também estatísticas globais da plataforma. As restantes páginas cobrem as informações e operações relevantes de cada entidade: listagem, detalhe, criação, edição e remoção de recursos, posts, comentários, utilizadores e filiações. A página de detalhe de um recurso permite ainda descarregá-lo como pacote DIP, e administradores dispõem de uma área dedicada para aprovar ou rejeitar recursos pendentes, e para exportar ou importar toda a plataforma sob a forma de um pacote ZIP que combina dados e ficheiros.

### Soft-delete

Em vez de uma eliminação destrutiva, tanto utilizadores como filiações usam o conceito de **soft-delete**: um campo `ativo`/`ativa` que é alterado para `false` em vez de a entrada ser removida. Os registos antigos continuam acessíveis para fins históricos (recursos, posts e comentários permanecem ligados ao seu autor) mas o utilizador deixa de poder aceder ao sistema, recebendo o erro **403 — Conta desativada** no login. Os cartões dos utilizadores desativados aparecem visualmente esbatidos, com um *pill* "Inativo".

### Documentação OpenAPI

Cada serviço Express expõe a sua própria documentação **OpenAPI 3.0** sob `/api-docs`, gerada com `swagger-ui-express` a partir de um ficheiro `swagger.json` versionado. Tanto a `data-api`, como o `web` e o `authentication` documentam os seus endpoints, permitindo explorar a API de forma interativa.

---

## Serviço de Autenticação (authentication)

O serviço `authentication` é responsável pelo login, registo e logout dos utilizadores. É o único serviço diretamente acessível pelo browser para
operações de autenticação. Após o login bem-sucedido, o utilizador é redirecionado para o serviço `web` e todas as interações subsequentes são feitas através deste serviço.

### Login e Emissão de Token

O processo de login é tratado em três passos encadeados como middlewares Express. O middleware `checkCredentials` envia as credenciais introduzidas pelo utilizador para o endpoint `POST /api/users/login` da `data-api`, que verifica a password com *bcrypt* e devolve os dados do utilizador. De seguida, `generateToken` assina um **JWT** com as claims do utilizador — identificador, email, nome, nível e filiação — com uma validade de 3 horas. O token é colocado num cookie `httpOnly`, inacessível ao JavaScript do browser. Por fim, o utilizador é redirecionado para o serviço `web`.

A validação de credenciais bloqueia ativamente os utilizadores com `ativo: false`, devolvendo um **HTTP 403** com mensagem clara em vez de aceitar o login, mesmo que a password esteja correta. No mesmo passo, a `data-api` actualiza o campo `dataUltimoAcesso` para o instante do login, com uma operação assíncrona *fire-and-forget* que não atrasa nem compromete a resposta. Este timestamp é depois apresentado no detalhe e nos cartões de cada utilizador, permitindo aos administradores monitorizar a atividade.

### Registo

O registo cria um novo utilizador com nível `consumidor` por defeito, enviando os dados para `POST /api/users/register` da `data-api`. Após o registo bem-sucedido, é feito o login automático, as credenciais são usadas imediatamente para obter os dados do utilizador, gerar o token e redirecionar para a plataforma, sem necessidade de o utilizador fazer login manualmente. O formulário de registo carrega dinamicamente as filiações  ativas disponíveis a partir da `data-api`.

### Logout

O logout é tratado pela função `clearCookie`, que limpa o cookie de autenticação e redireciona o utilizador para a página de login, terminando a sessão do lado do cliente.

---

## Conclusão

O desenvolvimento desta plataforma permitiu pôr em prática, num único projeto, vários conceitos centrais da unidade curricular de Engenharia Web. A separação em quatro serviços independentes — base de dados, API de dados, interface e autenticação — orquestrados com Docker Compose, demonstrou na prática as vantagens de uma arquitetura de microserviços: cada componente é responsável por uma única tarefa, comunica com os restantes através de contratos bem definidos (HTTP + JSON) e pode ser substituído ou escalado de forma isolada. Esta organização também simplificou o desenvolvimento em equipa, com cada elemento a poder trabalhar num serviço sem interferir com os outros.

Do ponto de vista funcional, foram cumpridos todos os requisitos centrais: gestão completa de utilizadores, recursos, posts, comentários e filiações; controlo de acesso baseado em três níveis (administrador, produtor, consumidor); workflow de moderação de recursos com aprovação/rejeição; sistema de visibilidade granular (pública, privada e restrita por filiação); e suporte a normas de preservação digital com a ingestão de SIPs e a exportação de DIPs no formato BagIt. 

Do ponto de vista técnico, destacam-se algumas decisões de design importantes: uso de **JWT em cookie `httpOnly`** para autenticação resistente a XSS; **Mongoose** com `timestamps` automáticos e índices estratégicos para garantir consistência e desempenho; **bcrypt** com 12 rondas para o armazenamento de passwords; **`archiver`** em modo *streaming* para evitar materializar grandes volumes em memória durante o export; e validações defensivas em todas as fronteiras (verificação de tipo de ficheiro, *path-traversal*, integridade de checksums BagIt, e regras de visibilidade aplicadas no servidor independentemente da UI).

Em síntese, o trabalho cumpre o objetivo de fornecer uma plataforma completa, segura e extensível para a gestão de recursos educativos, ao mesmo tempo que serviu como exercício real de aplicação dos conceitos teóricos de arquiteturas web modernas: APIs REST, autenticação com tokens, contentorização, microserviços e padrões de preservação digital. A solução final é também relativamente fácil de evoluir — novos tipos de recursos, novos níveis de acesso ou novas integrações externas podem ser adicionados sem alterações disruptivas, graças à clara separação de responsabilidades entre serviços.

