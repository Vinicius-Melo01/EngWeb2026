# **Engenharia Web 2026**

---
## **Maio de 2026**
---
### **Autores**

* **Autor 1**
    * ID: A104004
    * Nome: Diogo José Fernandes Esteves
    * Foto: <img src="pics/Pic1.jpeg" width="20%" />

* **Autor 2**
    * ID: A98286
    * Nome: Luis Filipe Araújo Ferreira
    * Foto: <img src="pics/Pic2.jpg" width="20%" />

* **Autor 3**
    * ID: A101926
    * Nome: Vinícius Gomes Roriz de Melo
    * Foto: <img src="pics/Pic3.jpg" width="20%" />

### Resumo : 

* Repositório de suporte ao projeto final da UC de Engenharia Web 2026, focado no desenvolvimento de uma Plataforma de Gestão e Disponibilização de Recursos Educativos com suporte à norma arquivística OAIS.
* O sistema é baseado numa arquitetura de microsserviços com autenticação JWT e é composto por três módulos principais: o **Servidor de Autenticação** (porta 3002, responsável pela gestão de acessos e emissão de tokens), a **API de Dados** (porta 3000, backend REST para CRUD de recursos, utilizadores, posts, e ingestão/exportação de pacotes SIP/DIP no formato BagIt) e o **Servidor Web** (porta 3001, frontend desenvolvido em Express/Pug que atua como interface para consumidores, produtores e administradores). A base de dados utilizada é o MongoDB.

### Instruções de Execução (Docker):

1. **Pré-requisitos:**
   - Ter o **Docker** e o **Docker Compose** instalados na máquina.

2. **Configuração do Ambiente:**
   - Na raiz do projeto, copia o ficheiro de exemplo das variáveis de ambiente para criar a tua própria configuração local:
     ```bash
     cp .env.example .env
     ```
   - Abre o ficheiro `.env` recém-criado e adapta os valores das variáveis (como portas, `MONGODB_URI` ou `JWT_SECRET`) caso seja necessário para o teu ambiente.

3. **Iniciar os Serviços:**
   - Na raiz do repositório, executa o seguinte comando para construir as imagens e levantar todos os contentores definidos no Compose (MongoDB, API de Dados, App Web e Autenticação):
     ```bash
     docker compose up -d --build
     ```

4. **Acesso à Plataforma:**
   - Após os serviços iniciarem, abre o teu browser e acede à interface principal através do endereço correspondente à porta configurada para o serviço `web` no teu ficheiro `.env` (tipicamente `http://localhost:3001` se a variável `WEB_PORT=3001`).

5. **Parar os Serviços:**
   - Para desligar a plataforma e remover os contentores de forma segura, executa:
     ```bash
     docker compose down
     ```
6. **Parar os Serviços e limpar a base de dados:**
   - Para desligar a plataforma e remover os contentores de forma segura, executa:
     ```bash
     docker compose down -v
     ```
### Lista de Resultados: 

**Documentação OpenAPI:**
* [Especificação OpenAPI (Swagger) - Servidor de Autenticação](./authentication/swagger.json)
* [Especificação OpenAPI (Swagger) - API de Dados](./data-api/src/swagger.json)
* [Especificação OpenAPI (Swagger) - Servidor Web](./web/swagger.json)

**Código Fonte:**
* [Código Fonte - Servidor de Autenticação](./authentication)
* [Código Fonte - API de Dados](./data-api)
* [Código Fonte - Servidor Web / Frontend](./web)