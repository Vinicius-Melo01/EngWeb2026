import json

# ----------------
# UTILIZADORES
# ----------------

utilizadores = [
    {
        "_id": "u1",
        "nome": "José Carlos Ramalho",
        "email": "jcr@di.uminho.pt",
        "filiacao": {"tipo": "docente", "departamento": "DI", "instituicao": "Universidade do Minho"},
        "nivel": "administrador",
        "dataRegisto": "2024-01-10",
        "dataUltimoAcesso": "2026-03-20",
        "password": "password123"
    },
    {
        "_id": "u2",
        "nome": "Ana Silva",
        "email": "ana.silva@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Engenharia Informática", "instituicao": "Universidade do Minho"},
        "nivel": "produtor",
        "dataRegisto": "2024-09-15",
        "dataUltimoAcesso": "2026-03-18",
        "password": "password123"
    },
    {
        "_id": "u3",
        "nome": "Bruno Costa",
        "email": "bruno.costa@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Engenharia Informática", "instituicao": "Universidade do Minho"},
        "nivel": "produtor",
        "dataRegisto": "2024-09-15",
        "dataUltimoAcesso": "2026-03-17",
        "password": "password123"
    },
    {
        "_id": "u4",
        "nome": "Catarina Mendes",
        "email": "catarina.mendes@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Ciências da Computação", "instituicao": "Universidade do Minho"},
        "nivel": "consumidor",
        "dataRegisto": "2025-02-01",
        "dataUltimoAcesso": "2026-03-19",
        "password": "password123"
    },
    {
        "_id": "u5",
        "nome": "Diogo Ferreira",
        "email": "diogo.ferreira@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Engenharia Informática", "instituicao": "Universidade do Minho"},
        "nivel": "consumidor",
        "dataRegisto": "2025-03-10",
        "dataUltimoAcesso": "2026-03-21",
        "password": "password123"
    },
    {
        "_id": "u6",
        "nome": "Filipa Rocha",
        "email": "filipa.rocha@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Engenharia Informática", "instituicao": "Universidade do Minho"},
        "nivel": "produtor",
        "dataRegisto": "2024-09-20",
        "dataUltimoAcesso": "2026-03-22",
        "password": "password123"
    },
    {
        "_id": "u7",
        "nome": "Gonçalo Pinto",
        "email": "goncalo.pinto@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Licenciatura em Informática", "instituicao": "Universidade do Minho"},
        "nivel": "produtor",
        "dataRegisto": "2024-10-01",
        "dataUltimoAcesso": "2026-03-20",
        "password": "password123"
    },
    {
        "_id": "u8",
        "nome": "Helena Sousa",
        "email": "helena.sousa@alunos.uminho.pt",
        "filiacao": {"tipo": "estudante", "curso": "Ciências da Computação", "instituicao": "Universidade do Minho"},
        "nivel": "consumidor",
        "dataRegisto": "2025-01-05",
        "dataUltimoAcesso": "2026-03-19",
        "password": "password123"
    },
    {
        "_id": "u9",
        "nome": "Igor Martins",
        "email": "igor.martins@di.uminho.pt",
        "filiacao": {"tipo": "docente", "departamento": "DI", "instituicao": "Universidade do Minho"},
        "nivel": "produtor",
        "dataRegisto": "2024-01-12",
        "dataUltimoAcesso": "2026-03-21",
        "password": "password123"
    }
]

# ----------------
# RECURSOS
# ----------------

recursos_data = [
    # --- programa/c ---
    {
        "_id": "r1",
        "produtor": "u1",
        "tipo": "programa/c",
        "titulo": "Leitura de um inteiro com scanf",
        "subtitulo": None,
        "path": "uploads/programs/C/scan1int.c",
        "visibilidade": "público",
        "dataRegisto": "2024-01-10",
        "dataUltimaAlteracao": "2024-01-10",
        "hashtags": ["C", "scanf", "programação imperativa"]
    },
    {
        "_id": "r2",
        "produtor": "u1",
        "tipo": "programa/c",
        "titulo": "Leitura de um inteiro com getchar()",
        "subtitulo": None,
        "path": "uploads/programs/C/parseint.c",
        "visibilidade": "público",
        "dataRegisto": "2024-01-10",
        "dataUltimaAlteracao": "2024-01-10",
        "hashtags": ["C", "getchar", "programação imperativa"]
    },
    {
        "_id": "r3",
        "produtor": "u1",
        "tipo": "programa/c",
        "titulo": "Leitura de uma string com getchar()",
        "subtitulo": None,
        "path": "uploads/programs/C/ler_str.c",
        "visibilidade": "público",
        "dataRegisto": "2024-01-10",
        "dataUltimaAlteracao": "2024-01-10",
        "hashtags": ["C", "strings", "programação imperativa"]
    },
    {
        "_id": "r4",
        "produtor": "u1",
        "tipo": "programa/c",
        "titulo": "Aplicação demo de alunos com persistência em ficheiros",
        "subtitulo": "Módulo Aluno: construtores, visualizadores, persistência em ficheiros de texto",
        "path": "uploads/programs/C/alunos.c",
        "visibilidade": "público",
        "dataRegisto": "2024-01-15",
        "dataUltimaAlteracao": "2024-02-01",
        "hashtags": ["C", "structs", "ficheiros", "programação imperativa"]
    },
    # --- texto/txt ---
    {
        "_id": "r5",
        "produtor": "u2",
        "tipo": "texto/txt",
        "titulo": "Alma",
        "subtitulo": None,
        "path": "uploads/text/txt/alma.txt",
        "visibilidade": "público",
        "dataRegisto": "2025-01-20",
        "dataUltimaAlteracao": "2025-01-20",
        "hashtags": ["texto", "literatura"]
    },
    {
        "_id": "r6",
        "produtor": "u2",
        "tipo": "texto/txt",
        "titulo": "Arte",
        "subtitulo": None,
        "path": "uploads/text/txt/arte.txt",
        "visibilidade": "público",
        "dataRegisto": "2025-01-20",
        "dataUltimaAlteracao": "2025-01-20",
        "hashtags": ["texto", "literatura"]
    },
    {
        "_id": "r7",
        "produtor": "u2",
        "tipo": "texto/txt",
        "titulo": "Metafísica",
        "subtitulo": None,
        "path": "uploads/text/txt/metafisica.txt",
        "visibilidade": "público",
        "dataRegisto": "2025-01-20",
        "dataUltimaAlteracao": "2025-01-20",
        "hashtags": ["texto", "filosofia"]
    },
    # --- datasets/json ---
    {
        "_id": "r8",
        "produtor": "u9",
        "tipo": "datasets/json",
        "titulo": "Dataset de Cinema",
        "subtitulo": "Base de dados de filmes com atores e géneros",
        "path": "uploads/datasets/json/cinema.json",
        "visibilidade": "público",
        "dataRegisto": "2024-03-01",
        "dataUltimaAlteracao": "2024-03-01",
        "hashtags": ["cinema", "dataset", "JSON", "filmes"]
    },
    {
        "_id": "r9",
        "produtor": "u9",
        "tipo": "datasets/json",
        "titulo": "Dataset de Reparações de Viaturas",
        "subtitulo": "Registos de intervenções e manutenções automóvel",
        "path": "uploads/datasets/json/dataset_reparacoes.json",
        "visibilidade": "público",
        "dataRegisto": "2024-03-05",
        "dataUltimaAlteracao": "2024-03-05",
        "hashtags": ["reparações", "dataset", "JSON", "automóvel"]
    },
    {
        "_id": "r10",
        "produtor": "u9",
        "tipo": "datasets/json",
        "titulo": "Publicações do JCR",
        "subtitulo": "Lista de publicações académicas do Professor José Carlos Ramalho",
        "path": "uploads/datasets/json/jcrpubs.json",
        "visibilidade": "público",
        "dataRegisto": "2024-03-10",
        "dataUltimaAlteracao": "2024-03-10",
        "hashtags": ["publicações", "dataset", "JSON", "académico"]
    },
    {
        "_id": "r11",
        "produtor": "u6",
        "tipo": "datasets/json",
        "titulo": "Dataset de EMDs",
        "subtitulo": "Dados de Exames Médico-Desportivos",
        "path": "uploads/datasets/json/emd.json",
        "visibilidade": "público",
        "dataRegisto": "2024-04-01",
        "dataUltimaAlteracao": "2024-04-01",
        "hashtags": ["EMD", "dataset", "JSON", "desporto"]
    },
    {
        "_id": "r12",
        "produtor": "u6",
        "tipo": "datasets/json",
        "titulo": "Mapa de Portugal",
        "subtitulo": "Dataset geográfico com concelhos e distritos de Portugal",
        "path": "uploads/datasets/json/mapa.json",
        "visibilidade": "público",
        "dataRegisto": "2024-04-05",
        "dataUltimaAlteracao": "2024-04-05",
        "hashtags": ["mapa", "dataset", "JSON", "geografia", "Portugal"]
    },
    {
        "_id": "r13",
        "produtor": "u7",
        "tipo": "datasets/json",
        "titulo": "Arquivo Sonoro - Dataset",
        "subtitulo": "Base de dados de arquivo de música digital",
        "path": "uploads/datasets/json/arq-son.json",
        "visibilidade": "público",
        "dataRegisto": "2024-05-01",
        "dataUltimaAlteracao": "2024-05-01",
        "hashtags": ["música", "arquivo", "dataset", "JSON"]
    },
    {
        "_id": "r14",
        "produtor": "u7",
        "tipo": "datasets/json",
        "titulo": "Base de Dados de Alunos de Música",
        "subtitulo": "Alunos com instrumento, curso e ano curricular",
        "path": "uploads/datasets/json/db.json",
        "visibilidade": "público",
        "dataRegisto": "2024-05-10",
        "dataUltimaAlteracao": "2024-05-10",
        "hashtags": ["música", "alunos", "dataset", "JSON", "conservatório"]
    },
    {
        "_id": "r15",
        "produtor": "u7",
        "tipo": "datasets/json",
        "titulo": "Dataset Eurovision Song Contest",
        "subtitulo": "Músicas por edição desde 1956: título, país, compositor e intérprete",
        "path": "uploads/datasets/json/dataset.json",
        "visibilidade": "público",
        "dataRegisto": "2024-05-15",
        "dataUltimaAlteracao": "2024-05-15",
        "hashtags": ["eurovision", "música", "dataset", "JSON", "competição"]
    },
    # --- datasets/xml ---
    {
        "_id": "r16",
        "produtor": "u9",
        "tipo": "datasets/xml",
        "titulo": "Arqueossítios do Noroeste Português - Parte 1",
        "subtitulo": "Dados XML sobre arqueossítios com transformação XSLT",
        "path": "uploads/datasets/xml/arqueossitios_xml_xsl/arq1.xml",
        "visibilidade": "público",
        "dataRegisto": "2024-02-15",
        "dataUltimaAlteracao": "2024-02-15",
        "hashtags": ["XML", "arqueologia", "XSLT", "noroeste"]
    },
    {
        "_id": "r17",
        "produtor": "u9",
        "tipo": "datasets/xml",
        "titulo": "Arqueossítios do Noroeste Português - Parte 2",
        "subtitulo": "Continuação do dataset XML com mais registos",
        "path": "uploads/datasets/xml/arqueossitios_xml_xsl/arq2.xml",
        "visibilidade": "público",
        "dataRegisto": "2024-02-15",
        "dataUltimaAlteracao": "2024-02-15",
        "hashtags": ["XML", "arqueologia", "XSLT", "noroeste"]
    },
    {
        "_id": "r18",
        "produtor": "u9",
        "tipo": "datasets/xml",
        "titulo": "Arqueossítios do Noroeste Português - Parte 3",
        "subtitulo": "Terceira parte do dataset com transformação HTML",
        "path": "uploads/datasets/xml/arqueossitios_xml_xsl/arq3.xml",
        "visibilidade": "público",
        "dataRegisto": "2024-02-20",
        "dataUltimaAlteracao": "2024-02-20",
        "hashtags": ["XML", "arqueologia", "XSLT"]
    },
    {
        "_id": "r19",
        "produtor": "u9",
        "tipo": "datasets/xml",
        "titulo": "Transformação XSLT para Arqueossítios",
        "subtitulo": "Folha de estilo XSL para converter XML de arqueossítios em HTML",
        "path": "uploads/datasets/xml/arqueossitios_xml_xsl/arq2html.xsl",
        "visibilidade": "público",
        "dataRegisto": "2024-02-20",
        "dataUltimaAlteracao": "2024-02-20",
        "hashtags": ["XSLT", "XML", "transformação", "HTML"]
    },
    # --- fichas e testes (sem ficheiro físico ainda) ---
    {
        "_id": "r20",
        "produtor": "u1",
        "tipo": "texto/txt",
        "titulo": "Ficha de Expressões Regulares",
        "subtitulo": "Processador de Questionários, Expansor de Abreviaturas, Tokenizer e outros",
        "path": None,
        "visibilidade": "público",
        "dataRegisto": "2024-03-01",
        "dataUltimaAlteracao": "2024-03-01",
        "hashtags": ["expressões regulares", "PL", "tokenizer"]
    },
    {
        "_id": "r21",
        "produtor": "u1",
        "tipo": "texto/txt",
        "titulo": "Ficha de MongoDB",
        "subtitulo": "Gestão de inscrições numa prova desportiva, avaliações e publicações",
        "path": None,
        "visibilidade": "público",
        "dataRegisto": "2024-03-05",
        "dataUltimaAlteracao": "2024-03-05",
        "hashtags": ["MongoDB", "bases de dados", "NoSQL"]
    },
    {
        "_id": "r22",
        "produtor": "u1",
        "tipo": "texto/txt",
        "titulo": "Miniteste PI - Listas Ligadas (2010)",
        "subtitulo": "Versões A e B",
        "path": None,
        "visibilidade": "público",
        "dataRegisto": "2024-04-05",
        "dataUltimaAlteracao": "2024-04-05",
        "hashtags": ["miniteste", "programação imperativa", "listas ligadas"]
    },
    {
        "_id": "r23",
        "produtor": "u1",
        "tipo": "texto/txt",
        "titulo": "Miniteste PI - Árvores Binárias (2010)",
        "subtitulo": "Versões A e B",
        "path": None,
        "visibilidade": "público",
        "dataRegisto": "2024-04-05",
        "dataUltimaAlteracao": "2024-04-05",
        "hashtags": ["miniteste", "programação imperativa", "árvores binárias"]
    },
    # --- privado ---
    {
        "_id": "r24",
        "produtor": "u3",
        "tipo": "texto/txt",
        "titulo": "Notas pessoais de estudo - Compiladores",
        "subtitulo": None,
        "path": None,
        "visibilidade": "privado",
        "dataRegisto": "2025-11-01",
        "dataUltimaAlteracao": "2025-11-05",
        "hashtags": ["compiladores", "estudo"]
    }
]

# ----------------
# POSTS
# ----------------

posts = [
    {"_id": "p1",  "produtor": "u2", "dataCriacao": "2026-01-10", "texto": "Excelente recurso para quem está a aprender leitura de inteiros em C. O exemplo com scanf é muito direto.", "comentarios": [], "dados": "r1",  "classificacaoMedia": 4.5},
    {"_id": "p2",  "produtor": "u3", "dataCriacao": "2026-01-15", "texto": "A ficha de Expressões Regulares é muito completa. Cobre desde tokenizers simples até processadores mais complexos.", "comentarios": [], "dados": "r20", "classificacaoMedia": 4.8},
    {"_id": "p3",  "produtor": "u4", "dataCriacao": "2026-02-01", "texto": "A ficha de MongoDB é das melhores para perceber aggregation pipelines. Complemento perfeito às aulas.", "comentarios": [], "dados": "r21", "classificacaoMedia": 4.9},
    {"_id": "p4",  "produtor": "u6", "dataCriacao": "2026-02-05", "texto": "O dataset de cinema é perfeito para praticar queries MongoDB e Express. Usei-o no TPC6 e correu muito bem.", "comentarios": [], "dados": "r8",  "classificacaoMedia": 4.6},
    {"_id": "p5",  "produtor": "u7", "dataCriacao": "2026-02-10", "texto": "O dataset de reparações tem arrays aninhados — bom para praticar $unwind no MongoDB.", "comentarios": [], "dados": "r9",  "classificacaoMedia": 4.3},
    {"_id": "p6",  "produtor": "u5", "dataCriacao": "2026-02-15", "texto": "Os minitestes de Listas Ligadas são um bom treino antes do exame. Dificuldade progressiva.", "comentarios": [], "dados": "r22", "classificacaoMedia": 4.6},
    {"_id": "p7",  "produtor": "u2", "dataCriacao": "2026-03-01", "texto": "O exemplo de alunos em C com persistência em ficheiros é muito útil para perceber como estruturar um projeto maior.", "comentarios": [], "dados": "r4",  "classificacaoMedia": 4.8},
    {"_id": "p8",  "produtor": "u6", "dataCriacao": "2026-03-05", "texto": "O dataset das publicações do JCR é ótimo para praticar RDF e SPARQL. Estrutura muito bem organizada.", "comentarios": [], "dados": "r10", "classificacaoMedia": 4.7},
    {"_id": "p9",  "produtor": "u7", "dataCriacao": "2026-03-08", "texto": "Os ficheiros XML dos arqueossítios são um excelente exemplo real para praticar XSLT.", "comentarios": [], "dados": "r16", "classificacaoMedia": 4.4},
    {"_id": "p10", "produtor": "u9", "dataCriacao": "2026-03-12", "texto": "O dataset do mapa de Portugal é muito útil para quem quer trabalhar com dados geográficos em aplicações web.", "comentarios": [], "dados": "r12", "classificacaoMedia": 4.4},
    {"_id": "p11", "produtor": "u3", "dataCriacao": "2026-03-15", "texto": "A folha XSLT para arqueossítios é um bom exemplo de transformação XML->HTML.", "comentarios": [], "dados": "r19", "classificacaoMedia": 4.5},
    {"_id": "p12", "produtor": "u8", "dataCriacao": "2026-03-18", "texto": "O dataset de EMDs tem dados interessantes para praticar queries com filtros complexos.", "comentarios": [], "dados": "r11", "classificacaoMedia": 4.0}
]

# ----------------
# COMENTÁRIOS
# ----------------

comentarios = [
    {"_id": "c1",  "criador": "u3", "post": "p1",  "data": "2026-01-11", "texto": "Concordo! Uso este exemplo sempre que tenho de explicar scanf a colegas."},
    {"_id": "c2",  "criador": "u4", "post": "p1",  "data": "2026-01-12", "texto": "Muito útil. Seria bom ter também um exemplo com sscanf para comparar."},
    {"_id": "c3",  "criador": "u5", "post": "p2",  "data": "2026-01-16", "texto": "A parte do Tokenizer foi a mais desafiante. Alguém tem dicas?"},
    {"_id": "c4",  "criador": "u6", "post": "p2",  "data": "2026-01-17", "texto": "Para o Tokenizer recomendo reler a teoria de autómatos antes de tentar."},
    {"_id": "c5",  "criador": "u2", "post": "p3",  "data": "2026-02-02", "texto": "Os aggregation pipelines são mesmo o que faz diferença nos projetos."},
    {"_id": "c6",  "criador": "u7", "post": "p4",  "data": "2026-02-06", "texto": "Também usei este dataset. A parte dos géneros aninhados é perfeita para treinar $lookup."},
    {"_id": "c7",  "criador": "u8", "post": "p4",  "data": "2026-02-07", "texto": "Alguém sabe se há uma versão mais recente deste dataset com mais filmes?"},
    {"_id": "c8",  "criador": "u3", "post": "p5",  "data": "2026-02-11", "texto": "O $unwind nas intervenções foi o que me fez perceber este operador de vez."},
    {"_id": "c9",  "criador": "u4", "post": "p6",  "data": "2026-02-16", "texto": "Os minitestes de árvores binárias são ainda mais difíceis, aconselho também."},
    {"_id": "c10", "criador": "u8", "post": "p7",  "data": "2026-03-02", "texto": "Este exemplo foi a base do meu projeto de PI. Muito bem estruturado."},
    {"_id": "c11", "criador": "u5", "post": "p8",  "data": "2026-03-06", "texto": "Usei este dataset para a ficha de RDF. Tem uma estrutura muito limpa para converter."},
    {"_id": "c12", "criador": "u2", "post": "p9",  "data": "2026-03-09", "texto": "Os ficheiros XML dos arqueossítios são bons para perceber a estrutura de documentos reais."},
    {"_id": "c13", "criador": "u6", "post": "p9",  "data": "2026-03-10", "texto": "A transformação XSLT que acompanha é muito bem feita. Dá para aprender bastante só a ler."},
    {"_id": "c14", "criador": "u4", "post": "p10", "data": "2026-03-13", "texto": "Já usei este dataset para um projeto de visualização. Muito completo."},
    {"_id": "c15", "criador": "u8", "post": "p11", "data": "2026-03-16", "texto": "Boa dica! Estava mesmo a precisar de um exemplo de XSLT para a ficha."},
    {"_id": "c16", "criador": "u5", "post": "p12", "data": "2026-03-19", "texto": "Os dados de EMD têm datas e valores numéricos interessantes para praticar $group e $avg."}
]

# ----------------
# REFERÊNCIA: posts -> comentarios (única referência bidirecional restante)
# Utilizadores e Recursos já não guardam listas
# ----------------

posts_index = {p["_id"]: p for p in posts}
for c in comentarios:
    posts_index[c["post"]]["comentarios"].append(c["_id"])

# ----------------
# ESCREVER OS FICHEIROS JSON
# ----------------

ficheiros = {
    "utilizadores.json": utilizadores,
    "recursos.json":     recursos_data,
    "posts.json":        posts,
    "comentarios.json":  comentarios
}

for nome, dados in ficheiros.items():
    with open(nome, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
    print(f"✓ {nome} gerado ({len(dados)} documentos)")

print("\nDone! Copia os 4 ficheiros para mongodb/")